#!/usr/bin/env python3
"""Run the bot's existing idempotent database initializer."""
from app.legacy_bot import init_db

if __name__ == '__main__':
    init_db()
    print('Database migration completed.')
