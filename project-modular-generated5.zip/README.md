# Telegram VPN Shop — Modular Layout

The project is now organized by responsibility while preserving the existing production behavior. `run.py` is the only production entrypoint; `bot.py` remains a backward-compatible launcher.

## Directory layout

```text
telegram-vpn-shop/
├── app/
│   ├── config/settings.py              # .env loading and validation
│   ├── integrations/xui/client.py     # 3x-ui API adapter
│   ├── database/connection.py         # SQLite connection boundary
│   ├── services/redeem_codes.py       # reusable 5-code generation utility
│   └── legacy_bot.py                   # compatibility runtime and handlers
├── database/shop.sqlite3
├── deploy/shopbot.service
├── scripts/migrate_database.py
├── requirements.txt
├── run.py                             # production entrypoint
└── bot.py                             # compatibility entrypoint
```

The compatibility runtime is intentionally kept in `app/legacy_bot.py` during this first migration so existing orders, customer records, panel encryption, monitoring, and redeem-code behavior are not accidentally changed. New features should be added under `app/services`, `app/database`, `app/integrations`, and `app/bot/handlers`, then wired into `app/legacy_bot.py` through small adapters. This allows the remaining handlers to be migrated incrementally without downtime or a database reset.

## Production start

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python scripts/migrate_database.py
.venv/bin/python run.py
```

For systemd, install `deploy/shopbot.service` and ensure `.env` contains the existing `BOT_TOKEN`, `ADMIN_IDS`, and original `FERNET_KEY`. Do not create a second polling service with the same Bot token.

## Redeem batch flow

Admin sends `/redeem GENERATED`, chooses plan, days, panel, and inbound, and receives five one-time `FREE-...` codes. A customer sends one code; only then is a 3x-ui client created and delivered. Each code can be used once.
