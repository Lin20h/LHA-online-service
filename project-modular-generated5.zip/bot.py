"""Backward-compatible launcher. Use run.py for the modular project entrypoint."""
import asyncio
from app.legacy_bot import main

if __name__ == '__main__':
    asyncio.run(main())
