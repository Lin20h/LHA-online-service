"""3x-ui API adapter for compatible MHSanaei 3x-ui panels.

Creates a client through the panel API and formats share URIs for the supported
VLESS, VMess, Trojan and Shadowsocks protocols. Unsupported inbound structures fail closed.
"""
import base64, json, uuid, secrets
from datetime import datetime, timezone, timedelta
from urllib.parse import urlparse, urlencode, quote
import aiohttp
from dateutil.relativedelta import relativedelta

TIMEOUT = aiohttp.ClientTimeout(total=25)
class XUIError(Exception): pass

def _obj(payload): return payload.get('obj') if isinstance(payload,dict) and 'obj' in payload else payload
def _dict(value):
    if isinstance(value,str):
        try: return json.loads(value)
        except Exception: return {}
    return value if isinstance(value,dict) else {}

def _string_list(value):
    if value is None: return []
    if isinstance(value,list): return [str(x) for x in value if x is not None]
    if isinstance(value,str):
        text=value.strip()
        if not text: return []
        try:
            decoded=json.loads(text)
            if isinstance(decoded,list): return [str(x) for x in decoded if x is not None]
        except (json.JSONDecodeError,TypeError): pass
        return [part.strip() for part in text.replace('\n',',').split(',') if part.strip()]
    return [str(value)]

class XUIPanel:
    def __init__(self,base_url,username,password,share_host=None,verify_tls=True):
        self.base=base_url.rstrip('/'); self.username=username; self.password=password
        self.share_host=(share_host.strip() if share_host else (urlparse(base_url).hostname or ''))
        self.session=None; self.verify_tls=verify_tls; self.csrf_token=None
    async def __aenter__(self):
        connector=aiohttp.TCPConnector(ssl=self.verify_tls)
        self.session=aiohttp.ClientSession(timeout=TIMEOUT,connector=connector,cookie_jar=aiohttp.CookieJar(unsafe=True))
        await self.login(); return self
    async def __aexit__(self,*_):
        if self.session: await self.session.close()
    async def _request(self,method,path,**kwargs):
        headers=dict(kwargs.get('headers') or {})
        if method.upper() not in ('GET','HEAD','OPTIONS','TRACE') and self.csrf_token:
            headers.setdefault('X-CSRF-Token',self.csrf_token)
        if headers: kwargs['headers']=headers
        try:
            async with self.session.request(method,self.base+path,**kwargs) as r:
                text=await r.text()
                if r.status>=400: raise XUIError(f'3x-ui HTTP {r.status} [{method.upper()} {path}]: {text[:240]}')
                if not text.strip(): return {}
                try: return json.loads(text)
                except json.JSONDecodeError: return {'raw':text}
        except aiohttp.ClientError as e: raise XUIError(f'Panel ချိတ်ဆက်မရပါ: {e}') from e
    async def login(self):
        csrf=None
        try:
            token_response=await self._request('GET','/csrf-token')
            token_value=_obj(token_response)
            if isinstance(token_value,str): csrf=token_value
            elif isinstance(token_value,dict): csrf=token_value.get('token') or token_value.get('csrfToken')
        except XUIError:
            # Older panel versions may not expose CSRF-token endpoint.
            csrf=None
        self.csrf_token=csrf
        headers={'X-CSRF-Token':csrf} if csrf else {}
        first_error=None
        try:
            p=await self._request('POST','/login',json={'username':self.username,'password':self.password},headers=headers)
        except XUIError as e:
            first_error=e
            p=None
        if not (isinstance(p,dict) and p.get('success')):
            try:
                p=await self._request('POST','/login',data={'username':self.username,'password':self.password},headers=headers)
            except XUIError as e:
                if first_error:
                    raise XUIError(f'3x-ui login မအောင်မြင်ပါ။ CSRF token ရှိ/မရှိ၊ panel URL path နှင့် reverse-proxy access ကိုစစ်ပါ။ {e}') from e
                raise
        if isinstance(p,dict) and p.get('success') is False: raise XUIError('Panel login မအောင်မြင်ပါ။ username/password/URL ကိုစစ်ပါ။')
        return p
    async def inbounds(self):
        p=await self._request('GET','/panel/api/inbounds/list')
        if isinstance(p,dict) and p.get('success') is False: raise XUIError('Inbound list error: '+str(p.get('msg','unknown')))
        result=_obj(p)
        if not isinstance(result,list): raise XUIError('Inbound စာရင်းပုံစံမမှန်ပါ။ 3x-ui version/API ကိုစစ်ပါ။')
        return result
    async def online_clients(self):
        """Return currently connected client emails, independent of client app.

        3x-ui's online endpoint reports the Xray client identity (email), not
        whether the traffic came from V2Box, Hiddify, Karing, etc. That is the
        correct app-independent signal for a real server connection.
        """
        last_error=None
        for method,path in (('POST','/panel/api/clients/onlines'),('POST','/panel/api/inbounds/onlines'),('GET','/panel/api/inbounds/onlines')):
            try: response=await self._request(method,path)
            except XUIError as e:
                if 'HTTP 404' in str(e) or 'HTTP 405' in str(e): last_error=e; continue
                raise
            if isinstance(response,dict) and response.get('success') is False:
                raise XUIError('3x-ui online client API အမှား: '+str(response.get('msg','မသိပါ')))
            result=_obj(response)
            if result is None: return set()
            if isinstance(result,str):
                try: result=json.loads(result)
                except json.JSONDecodeError: result=[x.strip() for x in result.replace('\n',',').split(',') if x.strip()]
            if isinstance(result,dict):
                nested=next((result[k] for k in ('emails','online','onlines','clients') if k in result),None)
                if nested is not None: result=nested
                elif all(isinstance(v,(int,float,bool,str)) for v in result.values()):
                    return {str(k) for k,v in result.items() if str(v).strip().lower() not in ('','0','false','none')}
            if isinstance(result,str): result=[result]
            if isinstance(result,list):
                emails=set()
                for item in result:
                    if isinstance(item,str) and item.strip(): emails.add(item.strip())
                    elif isinstance(item,dict) and item.get('email'): emails.add(str(item['email']).strip())
                return emails
            raise XUIError('3x-ui online client API တုံ့ပြန်ချက်ပုံစံမမှန်ပါ။')
        raise XUIError(f'3x-ui online client endpoint မတွေ့ပါ။ Panel version/API ကိုစစ်ပါ။ {last_error or ""}')

    async def hwid_status(self,email):
        """Read the panel's registered HWID count/limit for one client.

        The response shape changed across 3x-ui versions, so this normalizes
        list and object responses. It is metadata only; online_clients() remains
        the gate for a first *actual* server connection notification.
        """
        path=f'/panel/api/clients/hwids/{quote(str(email),safe="")}'
        try:
            response=await self._request('POST',path)
        except XUIError as e:
            if 'HTTP 404' in str(e) or 'HTTP 405' in str(e):
                return {'count':None,'limit':None,'available':False}
            raise
        if isinstance(response,dict) and response.get('success') is False:
            raise XUIError('3x-ui HWID API အမှား: '+str(response.get('msg','မသိပါ')))
        value=_obj(response)
        if isinstance(value,str):
            try: value=json.loads(value)
            except json.JSONDecodeError: value=[]
        limit=None; devices=value
        if isinstance(value,dict):
            limit=value.get('limitHwid',value.get('hwidDeviceLimit',value.get('limit')))
            devices=next((value[k] for k in ('hwids','devices','items','data') if k in value),[])
        if not isinstance(devices,list): devices=[] if devices is None else [devices]
        try: limit=int(limit) if limit is not None else None
        except (TypeError,ValueError): limit=None
        return {'count':len(devices),'limit':limit,'available':True}
    async def add_client(self,inbound,user_id,months,devices,tag,duration_days=None):
        iid=int(inbound.get('id')); protocol=str(inbound.get('protocol','')).lower()
        # Deterministic identifiers make retrying the same order idempotent.
        email=''.join(ch if ch.isalnum() or ch in '-_' else '-' for ch in f'{tag}-{user_id}')[:64]
        stable=uuid.uuid5(uuid.NAMESPACE_URL,f'3xui:{self.base}:{iid}:{email}')
        credential=str(stable)
        expiry=datetime.now(timezone.utc)+(timedelta(days=int(duration_days)) if duration_days is not None else relativedelta(months=int(months)))
        expires=int(expiry.timestamp()*1000)
        term_label=f'{duration_days}d' if duration_days is not None else f'{months}m'
        client={'id':credential,'email':email,'enable':True,'limitIp':int(devices),'hwidDeviceLimit':int(devices),
                'totalGB':0,'expiryTime':expires,'tgId':int(user_id),'subId':stable.hex[:16],
                'comment':f'{tag} • {term_label} • {devices}d'}
        if protocol=='trojan': client['password']=credential
        if protocol=='shadowsocks':
            ss_method=str(_dict(inbound.get('settings')).get('method') or '').lower()
            if not ss_method: raise XUIError('Shadowsocks cipher/method မတွေ့ပါ။ Inbound settings ကိုစစ်ပါ။')
            if ss_method.startswith('2022-blake3-aes-128-'):
                client['password']=base64.b64encode(secrets.token_bytes(16)).decode()
            elif ss_method.startswith('2022-blake3-'):
                client['password']=base64.b64encode(secrets.token_bytes(32)).decode()
            else:
                client['password']=secrets.token_urlsafe(24)
        if protocol=='vless': client['flow']=self._flow(inbound)
        settings=_dict(inbound.get('settings')); current=settings.get('clients') or []
        # Retry after an interrupted response: reuse the already-created account.
        prior=next((x for x in current if x.get('email')==email),None)
        if prior:
            client.update(prior)
        else:
            # Verify the scheme can be rendered BEFORE a panel mutation.
            uri=self._share_uri(inbound,client)
            try:
                payload=await self._request('POST','/panel/api/inbounds/addClient',data={'id':iid,'settings':json.dumps({'clients':[client]},separators=(',',':'))})
            except XUIError as e:
                if 'HTTP 404' not in str(e): raise
                # Newer 3x-ui releases moved clients to first-class client records.
                modern_client=dict(client); modern_client['limitHwid']=int(devices)
                payload=await self._request('POST','/panel/api/clients/add',json={'client':modern_client,'inboundIds':[iid]})
            if isinstance(payload,dict) and payload.get('success') is False: raise XUIError('Client ဖန်တီးမှု API အမှား: '+str(payload.get('msg','မသိပါ')))
            # A false response is failure; empty successful response is normal on some versions.
            if isinstance(payload,dict) and payload.get('raw','').strip().lower() in ('false','error'):
                raise XUIError('Panel က client ဖန်တီးမှု မအောင်မြင်ကြောင်း ပြန်ပို့ပါသည်။ API တုံ့ပြန်ချက်ကို စစ်ဆေးပါ။')
        uri=self._share_uri(inbound,client)
        sub_id=str(client.get('subId') or '')
        if not sub_id: raise XUIError('3x-ui မှ subscription ID မရပါ။ Client ကိုစစ်ဆေးပါ။')
        subscription_url=await self.subscription_url(sub_id)
        return {'email':email,'uuid':client.get('id') or credential,'sub_id':sub_id,'expiry_ms':int(client.get('expiryTime') or expires),
                'uri':uri,'subscription_url':subscription_url,'protocol':protocol,'inbound':inbound.get('remark',str(iid))}
    async def subscription_url(self,sub_id):
        response=await self._request('POST','/panel/api/setting/defaultSettings')
        settings=_obj(response)
        if isinstance(response,dict) and response.get('success') is False:
            raise XUIError('3x-ui Subscription setting အမှား: '+str(response.get('msg','မသိပါ')))
        if not isinstance(settings,dict): raise XUIError('3x-ui မှ Subscription setting အချက်အလက်မရပါ။')
        enabled=settings.get('subEnable',True)
        if enabled is False or str(enabled).strip().lower() in ('false','0','no'):
            raise XUIError('3x-ui panel တွင် Subscription ကိုဖွင့်ပါ။ Panel Settings > Subscription ကိုစစ်ပါ။')
        base=str(settings.get('subURI') or '').strip()
        if not base.startswith(('https://','http://')):
            raise XUIError('3x-ui မှ မှန်ကန်သော Subscription URL မရပါ။ Panel Settings ထဲရှိ Subscription domain/port/path ကိုစစ်ပါ။')
        return base.rstrip('/')+'/'+quote(str(sub_id),safe='')
    async def set_client_enabled(self,inbound_id,email,enabled):
        email_path=quote(str(email),safe='')
        try:
            response=await self._request('GET',f'/panel/api/clients/get/{email_path}')
            payload=_obj(response)
            client=payload.get('client') if isinstance(payload,dict) else None
            if not isinstance(client,dict): raise XUIError('3x-ui မှ client အချက်အလက်အပြည့်အစုံ မရပါ။')
            client=dict(client)
            # Some 3x-ui builds serialize the client id as a JSON number even
            # though the update model requires id to be a string.
            if client.get('id') is not None: client['id']=str(client['id'])
            # Older panel responses can encode allowedIPs as JSON text, while
            # the update API model strictly expects []string.
            if 'allowedIPs' in client: client['allowedIPs']=_string_list(client['allowedIPs'])
            client['enable']=bool(enabled)
            updated=await self._request('POST',f'/panel/api/clients/update/{email_path}',json=client)
            if isinstance(updated,dict) and updated.get('success') is False:
                raise XUIError('3x-ui client ပြင်ဆင်မှု မအောင်မြင်ပါ: '+str(updated.get('msg','မသိပါ')))
            return bool(enabled)
        except XUIError as e:
            if 'HTTP 404' not in str(e): raise
        inbounds=await self.inbounds()
        inbound=next((x for x in inbounds if int(x.get('id',-1))==int(inbound_id)),None)
        if not inbound: raise XUIError('Client ပါဝင်သည့် inbound ကို panel တွင် မတွေ့ပါ။')
        settings=_dict(inbound.get('settings')); clients=settings.get('clients') or []
        client=next((x for x in clients if str(x.get('email',''))==str(email)),None)
        if not isinstance(client,dict): raise XUIError('ရွေးထားသော inbound တွင် client ကို မတွေ့ပါ။')
        client=dict(client); client['enable']=bool(enabled)
        legacy_id=client.get('id') or client.get('password') or email_path
        response=await self._request('POST',f'/panel/api/inbounds/updateClient/{quote(str(legacy_id),safe="")}',data={'id':int(inbound_id),'settings':json.dumps({'clients':[client]},separators=(',',':'))})
        if isinstance(response,dict) and response.get('success') is False:
            raise XUIError('Legacy 3x-ui client ပြင်ဆင်မှု မအောင်မြင်ပါ: '+str(response.get('msg','မသိပါ')))
        return bool(enabled)

    async def delete_client(self,inbound_id,email,client_id=None):
        email_path=quote(str(email),safe='')
        try:
            response=await self._request('POST',f'/panel/api/clients/del/{email_path}?keepTraffic=0')
            if response is False: raise XUIError('3x-ui client ဖျက်မှုကို အတည်မပြုနိုင်ပါ။')
            if isinstance(response,dict) and response.get('success') is False:
                raise XUIError('3x-ui client ဖျက်မှုမအောင်မြင်ပါ: '+str(response.get('msg','မသိပါ')))
            if isinstance(response,dict) and str(response.get('raw') or '').strip().lower() not in ('','true','success','ok'):
                raise XUIError('3x-ui client ဖျက်မှုတုံ့ပြန်ချက် မမှန်ပါ။')
            return True
        except XUIError as e:
            if not any(code in str(e) for code in ('HTTP 404','HTTP 405')): raise
            if not client_id: raise XUIError('Legacy 3x-ui ဖျက်ရန် client ID မရှိပါ။') from e
            try:
                response=await self._request('POST',f'/panel/api/inbounds/{int(inbound_id)}/delClient/{quote(str(client_id),safe="")}')
            except XUIError as legacy_error:
                raise XUIError(f'Client ဖျက်မှုမအောင်မြင်ပါ။ Modern API: {e}; Legacy API: {legacy_error}') from legacy_error
            if response is False:
                raise XUIError('Legacy 3x-ui client ဖျက်မှုကို အတည်မပြုနိုင်ပါ။')
            if isinstance(response,dict) and response.get('success') is False:
                raise XUIError('Legacy 3x-ui client ဖျက်မှုမအောင်မြင်ပါ: '+str(response.get('msg','မသိပါ')))
            if isinstance(response,dict) and str(response.get('raw') or '').strip().lower() not in ('','true','success','ok'):
                raise XUIError('Legacy 3x-ui client ဖျက်မှုတုံ့ပြန်ချက် မမှန်ပါ။')
            return True

    @staticmethod
    def _flow(inbound):
        stream=_dict(inbound.get('streamSettings')); net=stream.get('network','tcp'); security=stream.get('security','none')
        if net=='tcp' and security in ('tls','reality'): return 'xtls-rprx-vision'
        return ''
    def _share_uri(self,inbound,client):
        protocol=str(inbound.get('protocol','')).lower(); port=int(inbound.get('port') or 0)
        stream=_dict(inbound.get('streamSettings')); net=stream.get('network','tcp'); security=stream.get('security','none')
        host=self.share_host; name=quote(str(client.get('email') or 'client'))
        if not host or not port: raise XUIError('Public host/port မသတ်မှတ်နိုင်ပါ။ Panel host ကိုစစ်ပါ။')
        client_id=client.get('id'); password=client.get('password') or client_id
        if protocol=='vless':
            params={'type':net,'security':security}; flow=client.get('flow')
            if flow: params['flow']=flow
            sec=_dict(stream.get('securitySettings')) or stream
            if security=='reality':
                reality=_dict(sec.get('realitySettings')); settings=_dict(reality.get('settings'))
                pub=settings.get('publicKey') or settings.get('public_key')
                sni=reality.get('serverNames') or []; sid=reality.get('shortIds') or []
                if not pub or not sni or not sid: raise XUIError('REALITY publicKey/serverNames/shortIds ရှာမတွေ့ပါ။ Panel config စစ်ပါ။')
                params.update(pbk=pub,sni=sni[0],sid=sid[0],fp='chrome')
            elif security=='tls':
                tls=_dict(sec.get('tlsSettings')); sni=tls.get('serverName') or (tls.get('serverNames') or [''])[0]
                if sni: params['sni']=sni
            elif security not in ('none',''): raise XUIError(f'VLESS security {security} ကို support မလုပ်ပါ။')
            if net=='ws':
                ws=_dict(stream.get('wsSettings')); params['path']=ws.get('path','/')
                if _dict(ws.get('headers')).get('Host'): params['host']=ws['headers']['Host']
            elif net=='grpc': params['serviceName']=_dict(stream.get('grpcSettings')).get('serviceName','')
            elif net in ('xhttp','splithttp'): params['path']=_dict(stream.get('xhttpSettings') or stream.get('splithttpSettings')).get('path','/')
            elif net=='tcp':
                header=_dict(_dict(stream.get('tcpSettings')).get('header'))
                if header.get('type') and header['type']!='none': params['headerType']=header['type']
            else: raise XUIError(f'VLESS transport {net} ကို support မလုပ်သေးပါ။')
            return f'vless://{client_id}@{host}:{port}/?{urlencode(params)}#{name}'
        if protocol=='vmess':
            if security=='reality': raise XUIError('VMess+REALITY share URI ကို support မလုပ်သေးပါ။')
            data={'v':'2','ps':client.get('email','client'),'add':host,'port':str(port),'id':client_id,'aid':'0','scy':'auto','net':net,'type':'none','host':'','path':'','tls':'tls' if security=='tls' else ''}
            if net=='ws':
                ws=_dict(stream.get('wsSettings')); data['path']=ws.get('path','/'); data['host']=_dict(ws.get('headers')).get('Host','')
            elif net=='grpc': data['path']=_dict(stream.get('grpcSettings')).get('serviceName','')
            elif net not in ('tcp','kcp','http','ws','grpc'): raise XUIError(f'VMess transport {net} ကို support မလုပ်သေးပါ။')
            return 'vmess://'+base64.urlsafe_b64encode(json.dumps(data,separators=(',',':')).encode()).decode().rstrip('=')
        if protocol=='trojan':
            params={'type':net,'security':security}; sec=_dict(stream.get('securitySettings')) or stream
            if security=='tls':
                tls=_dict(sec.get('tlsSettings')); sni=tls.get('serverName') or (tls.get('serverNames') or [''])[0]
                if sni: params['sni']=sni
            elif security=='reality': raise XUIError('Trojan+REALITY URI ကို support မလုပ်သေးပါ။')
            if net=='ws':
                ws=_dict(stream.get('wsSettings')); params['path']=ws.get('path','/')
                if _dict(ws.get('headers')).get('Host'): params['host']=ws['headers']['Host']
            elif net=='grpc': params['serviceName']=_dict(stream.get('grpcSettings')).get('serviceName','')
            elif net not in ('tcp','ws','grpc'): raise XUIError(f'Trojan transport {net} ကို support မလုပ်သေးပါ။')
            return f'trojan://{password}@{host}:{port}/?{urlencode(params)}#{name}'
        if protocol=='shadowsocks':
            settings=_dict(inbound.get('settings')); method=str(settings.get('method') or '')
            if not method or not client.get('password'):
                raise XUIError('Shadowsocks cipher သို့မဟုတ် client password မရှိပါ။')
            if method.lower().startswith('2022-blake3-'):
                server_password=settings.get('password')
                if not server_password:
                    raise XUIError('Shadowsocks 2022 inbound တွင် server password မတွေ့ပါ။ Panel ထဲရှိ inbound settings ကိုစစ်ပါ။')
                # SIP022 encodes method:server-PSK:client-PSK as percent-encoded userinfo.
                userinfo=quote(f'{method}:{server_password}:{client.get("password")}',safe=':')
            else:
                # SIP002 legacy form: Base64(method:client-password)@host:port.
                userinfo=base64.urlsafe_b64encode(f'{method}:{client["password"]}'.encode()).decode().rstrip('=')
            return f'ss://{userinfo}@{host}:{port}#{name}'
        raise XUIError(f'{protocol or "unknown"} inbound ကို support မလုပ်သေးပါ။ VLESS/VMess/Trojan/Shadowsocks inbound ကိုရွေးပါ။')

