"""Application configuration loaded from the project .env file."""
from pathlib import Path
import os
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(PROJECT_ROOT / '.env')

TOKEN = os.getenv('BOT_TOKEN', '').strip()
if not TOKEN:
    raise RuntimeError('BOT_TOKEN မရှိပါ။ .env ထဲထည့်ပါ။')

try:
    ADMIN_IDS = {int(x.strip()) for x in os.getenv('ADMIN_IDS', '').split(',') if x.strip()}
except ValueError as exc:
    raise RuntimeError('ADMIN_IDS သည် Telegram numeric ID များဖြစ်ရပါမည်။') from exc
if not ADMIN_IDS:
    raise RuntimeError('ADMIN_IDS မရှိပါ။ .env ထဲတွင် Telegram ID ထည့်ပါ။')

DB_PATH = os.getenv('DB_PATH', str(PROJECT_ROOT / 'database' / 'shop.sqlite3'))
FERNET_KEY = os.getenv('FERNET_KEY', '').strip()
if not FERNET_KEY:
    raise RuntimeError('FERNET_KEY မရှိပါ။ .env ထဲထည့်ပါ။')

PROJECT_FILES_DIR = Path(os.getenv('PROJECT_FILES_DIR', str(PROJECT_ROOT))).expanduser().resolve()
