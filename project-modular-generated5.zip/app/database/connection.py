"""Database connection boundary for future repository modules.

The current compatibility runtime still owns its migration function in
app.legacy_bot.py; new code should import this connection helper instead of
opening SQLite connections directly.
"""
import sqlite3
from app.config.settings import DB_PATH

def connect():
    connection = sqlite3.connect(DB_PATH, timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute('PRAGMA foreign_keys=ON')
    return connection
