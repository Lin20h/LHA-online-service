# ================= TELEGRAM BOT =================

from app.integrations.xui.client import XUIError, XUIPanel, _dict, _obj, _string_list

import asyncio, logging, os, sqlite3, json, html, time, zipfile, tempfile
from collections import defaultdict, deque
from pathlib import Path
from datetime import datetime, timezone, timedelta
from dateutil.relativedelta import relativedelta
from cryptography.fernet import Fernet, InvalidToken
from aiogram import Bot, Dispatcher, F, BaseMiddleware
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from app.config.settings import TOKEN, ADMIN_IDS, DB_PATH, FERNET_KEY, PROJECT_FILES_DIR
fernet=Fernet(FERNET_KEY.encode())
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s'); log=logging.getLogger('shopbot')
bot=Bot(TOKEN); dp=Dispatcher(storage=MemoryStorage())
PLANS={'jp':('🇯🇵 JP',4500),'sg':('🇸🇬 SG',5500)}; MIN_TOPUP=1000
PAYMENT_INFO='💳 ငွေဖြည့်ရန်\n\nKPay: 09690993417\nအမည်: Lin Htet Aung\n\nWave: 09690993417\nအမည်: Than Than Sint\n\nငွေလွှဲပြီး screenshot ပို့ပါ။ မှတ်ချက်တွင် “bill” ဟုသာရေးပါ။'

class Flow(StatesGroup):
    months=State(); devices=State(); topup_amount=State(); topup_proof=State(); admin_amount=State()
    panel_name=State(); panel_url=State(); panel_user=State(); panel_pass=State(); panel_host=State()
    free_plan=State(); free_days=State()

def db():
    c=sqlite3.connect(DB_PATH,timeout=30); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c
def now(): return datetime.now(timezone.utc).isoformat()
def admin(uid): return uid in ADMIN_IDS
def money(n): return f'{int(n):,} ကျပ်'
def touch(uid,name,username=None,first_name=None,last_name=None):
    with db() as c: c.execute('''INSERT INTO users(id,name,created,username,first_name,last_name) VALUES(?,?,?,?,?,?)
        ON CONFLICT(id) DO UPDATE SET name=excluded.name,username=COALESCE(excluded.username,users.username),
        first_name=COALESCE(excluded.first_name,users.first_name),last_name=COALESCE(excluded.last_name,users.last_name)''',
        (uid,name,now(),username,first_name,last_name))
def balance(uid):
    with db() as c:
        r=c.execute('SELECT balance FROM users WHERE id=?',(uid,)).fetchone(); return r['balance'] if r else 0
def setting(key,default=''):
    with db() as c:
        r=c.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
        return r['value'] if r else default
def set_setting(key,value):
    with db() as c: c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,str(value)))
def maintenance_active(): return setting('maintenance_mode','0')=='1'
def active_pause(uid):
    with db() as c: r=c.execute('SELECT blocked_until FROM users WHERE id=?',(uid,)).fetchone()
    if not r or not r['blocked_until']: return None
    try: until=datetime.fromisoformat(r['blocked_until'])
    except ValueError: until=None
    if until and until>datetime.now(timezone.utc): return until
    with db() as c: c.execute('UPDATE users SET blocked_until=NULL WHERE id=?',(uid,))
    return None
def pause_customer(uid,minutes,name='Customer'):
    until=datetime.now(timezone.utc)+timedelta(minutes=minutes)
    with db() as c:
        c.execute('''INSERT INTO users(id,name,created,blocked_until) VALUES(?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET blocked_until=excluded.blocked_until''',(uid,name,now(),until.isoformat(timespec='seconds')))
    return until
def resume_customer(uid):
    with db() as c: return c.execute('UPDATE users SET blocked_until=NULL WHERE id=?',(uid,)).rowcount>0
def init_db():
    with db() as c:
        c.executescript('''PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT,balance INTEGER NOT NULL DEFAULT 0,created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS topups(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,amount INTEGER,proof_file TEXT,status TEXT DEFAULT 'pending',created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,plan TEXT,months INTEGER,devices INTEGER,amount INTEGER,status TEXT DEFAULT 'awaiting_admin',panel_id INTEGER,inbound_id INTEGER,client_info TEXT,created TEXT NOT NULL,key_enabled INTEGER NOT NULL DEFAULT 1,waiting_notified INTEGER NOT NULL DEFAULT 0,deleted_at TEXT,connection_notified INTEGER NOT NULL DEFAULT 1,first_connected_at TEXT,expiry_reminder_sent INTEGER NOT NULL DEFAULT 0,expiry_reminder_at TEXT);
        CREATE TABLE IF NOT EXISTS panels(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,base_url TEXT,username TEXT,password_enc TEXT,share_host TEXT,enabled INTEGER DEFAULT 1,created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,delta INTEGER,note TEXT,admin_id INTEGER,created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS free_keys(id INTEGER PRIMARY KEY AUTOINCREMENT,admin_id INTEGER,user_id INTEGER,plan TEXT,months INTEGER,devices INTEGER,panel_id INTEGER,inbound_id INTEGER,client_info TEXT,created TEXT NOT NULL,duration_days INTEGER,key_enabled INTEGER NOT NULL DEFAULT 1,deleted_at TEXT,connection_notified INTEGER NOT NULL DEFAULT 1,first_connected_at TEXT,expiry_reminder_sent INTEGER NOT NULL DEFAULT 0,expiry_reminder_at TEXT);
        CREATE TABLE IF NOT EXISTS redeem_codes(code TEXT PRIMARY KEY,admin_id INTEGER NOT NULL,free_key_id INTEGER NOT NULL UNIQUE,batch_id TEXT,created TEXT NOT NULL,used_by INTEGER,used_at TEXT);
        CREATE TABLE IF NOT EXISTS connection_events(id INTEGER PRIMARY KEY AUTOINCREMENT,key_type TEXT NOT NULL,key_id INTEGER NOT NULL,customer_id INTEGER,customer_name TEXT,username TEXT,issuer_admin_id INTEGER,plan TEXT,panel_name TEXT,inbound TEXT,client_email TEXT,client_app TEXT,hwid_count INTEGER,hwid_limit INTEGER,event_type TEXT NOT NULL DEFAULT 'first_connection',connected_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_connection_events_connected_at ON connection_events(id DESC);
        ''')
        redeem_cols={r['name'] for r in c.execute('PRAGMA table_info(redeem_codes)').fetchall()}
        if 'batch_id' not in redeem_cols: c.execute('ALTER TABLE redeem_codes ADD COLUMN batch_id TEXT')
        event_cols={r['name'] for r in c.execute('PRAGMA table_info(connection_events)').fetchall()}
        if 'hwid_count' not in event_cols: c.execute('ALTER TABLE connection_events ADD COLUMN hwid_count INTEGER')
        if 'hwid_limit' not in event_cols: c.execute('ALTER TABLE connection_events ADD COLUMN hwid_limit INTEGER')
        order_cols={r['name'] for r in c.execute('PRAGMA table_info(orders)').fetchall()}
        if 'key_enabled' not in order_cols: c.execute('ALTER TABLE orders ADD COLUMN key_enabled INTEGER NOT NULL DEFAULT 1')
        if 'waiting_notified' not in order_cols: c.execute('ALTER TABLE orders ADD COLUMN waiting_notified INTEGER NOT NULL DEFAULT 0')
        if 'deleted_at' not in order_cols: c.execute('ALTER TABLE orders ADD COLUMN deleted_at TEXT')
        if 'connection_notified' not in order_cols: c.execute('ALTER TABLE orders ADD COLUMN connection_notified INTEGER NOT NULL DEFAULT 1')
        if 'first_connected_at' not in order_cols: c.execute('ALTER TABLE orders ADD COLUMN first_connected_at TEXT')
        if 'expiry_reminder_sent' not in order_cols: c.execute('ALTER TABLE orders ADD COLUMN expiry_reminder_sent INTEGER NOT NULL DEFAULT 0')
        if 'expiry_reminder_at' not in order_cols: c.execute('ALTER TABLE orders ADD COLUMN expiry_reminder_at TEXT')
        free_cols={r['name'] for r in c.execute('PRAGMA table_info(free_keys)').fetchall()}
        if 'duration_days' not in free_cols: c.execute('ALTER TABLE free_keys ADD COLUMN duration_days INTEGER')
        if 'key_enabled' not in free_cols: c.execute('ALTER TABLE free_keys ADD COLUMN key_enabled INTEGER NOT NULL DEFAULT 1')
        if 'deleted_at' not in free_cols: c.execute('ALTER TABLE free_keys ADD COLUMN deleted_at TEXT')
        if 'connection_notified' not in free_cols: c.execute('ALTER TABLE free_keys ADD COLUMN connection_notified INTEGER NOT NULL DEFAULT 1')
        if 'first_connected_at' not in free_cols: c.execute('ALTER TABLE free_keys ADD COLUMN first_connected_at TEXT')
        if 'expiry_reminder_sent' not in free_cols: c.execute('ALTER TABLE free_keys ADD COLUMN expiry_reminder_sent INTEGER NOT NULL DEFAULT 0')
        if 'expiry_reminder_at' not in free_cols: c.execute('ALTER TABLE free_keys ADD COLUMN expiry_reminder_at TEXT')
        user_cols={r['name'] for r in c.execute('PRAGMA table_info(users)').fetchall()}
        for col in ('username','first_name','last_name','blocked_until'):
            if col not in user_cols: c.execute(f'ALTER TABLE users ADD COLUMN {col} TEXT')
        panel_cols={r['name'] for r in c.execute('PRAGMA table_info(panels)').fetchall()}
        if 'share_host' not in panel_cols: c.execute('ALTER TABLE panels ADD COLUMN share_host TEXT')
        if 'created' not in panel_cols: c.execute("ALTER TABLE panels ADD COLUMN created TEXT NOT NULL DEFAULT ''")

RECENT_CUSTOMER_MESSAGES=defaultdict(deque)
LAST_GATE_NOTICE={}
def gate_notice_allowed(uid):
    stamp=time.monotonic()
    if stamp-LAST_GATE_NOTICE.get(uid,0)<30: return False
    LAST_GATE_NOTICE[uid]=stamp
    return True

class CustomerAccessGate(BaseMiddleware):
    async def __call__(self,handler,event,data):
        user=getattr(event,'from_user',None)
        if not user or admin(user.id): return await handler(event,data)
        reason=None
        until=active_pause(user.id)
        if maintenance_active():
            reason='🚧 Bot ကို ပြုပြင်ထိန်းသိမ်းနေပါသည်။ ဝယ်ယူမှု၊ ငွေဖြည့်မှုနှင့် key ဝန်ဆောင်မှုများကို ခဏရပ်ထားပြီး ပြန်လည်ဖွင့်ချိန်တွင် ထပ်မံအသိပေးပါမည်။'
        elif until:
            reason=f'⏸️ သင့်အကောင့်ကို ယာယီခဏရပ်ထားပါသည်။ ပြန်အသုံးပြုနိုင်မည့်အချိန်: {until.strftime("%Y-%m-%d %H:%M UTC")}'
        if reason:
            show=gate_notice_allowed(user.id)
            if isinstance(event,CallbackQuery): await event.answer(reason if show else '',show_alert=show)
            elif isinstance(event,Message) and show: await event.answer(reason)
            return None
        if isinstance(event,Message):
            stamp=time.monotonic(); window=RECENT_CUSTOMER_MESSAGES[user.id]
            while window and stamp-window[0]>15: window.popleft()
            window.append(stamp)
            if len(window)>=9:
                until=pause_customer(user.id,1,user.full_name or 'Customer'); window.clear(); LAST_GATE_NOTICE[user.id]=stamp
                await event.answer(f"⏸️ စာတိုများ အချိန်တိုအတွင်း အလွန်များလာသောကြောင့် ၁ မိနစ် ယာယီရပ်ထားပါသည်။ ပြန်အသုံးပြုနိုင်မည့်အချိန်: {until.strftime('%H:%M UTC')}။")
                for aid in ADMIN_IDS:
                    try: await bot.send_message(aid,f'⚠️ Customer ကို spam ကာကွယ်မှုဖြင့် ၁ မိနစ် ယာယီရပ်ထားသည်။\n{user.full_name} • ID {user.id}')
                    except Exception: pass
                return None
        return await handler(event,data)

dp.message.outer_middleware(CustomerAccessGate())
dp.callback_query.outer_middleware(CustomerAccessGate())

def kb(rows): return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t,callback_data=d) for t,d in row] for row in rows])
def key_status_markup(kind,key_id,enabled):
    rows=[]
    if enabled is not None:
        target=0 if enabled else 1
        label='⏸️ Key ပိတ်ရန်' if enabled else '▶️ Key ပြန်ဖွင့်ရန်'
        rows.append([(label,f'keytoggle:{kind}:{key_id}:{target}')])
    rows.append([('🗑️ Key ဖျက်ရန်',f'keydel:{kind}:{key_id}')])
    return kb(rows)
def main_kb(uid):
    rows=[[('💎 ပလန်ဝယ်ယူမည်','buy'),('👛 လက်ကျန်ငွေ','balance')],[('➕ ငွေဖြည့်မည်','topup'),('📦 အော်ဒါမှတ်တမ်း','myorders')],[('🆘 အကူအညီ','help')]]
    if admin(uid): rows.append([('👑 Admin စီမံခန့်ခွဲမှု','admin')])
    return kb(rows)
SAFE_PROJECT_SUFFIXES={'.py','.md','.txt','.service'}
def project_files():
    backup_dir=PROJECT_FILES_DIR/'backups'
    try:
        if backup_dir.is_symlink(): raise OSError('Backup directory must not be a symlink')
        backup_dir.mkdir(parents=True,exist_ok=True)
        if not backup_dir.resolve().is_relative_to(PROJECT_FILES_DIR): raise OSError('Backup directory is outside the project root')
    except OSError:
        log.exception('Unsafe or inaccessible project backup directory')
        raise
    archive=backup_dir/'project-backup.zip'
    db_path=Path(DB_PATH).expanduser().resolve()
    if not db_path.is_file(): raise FileNotFoundError(f'Customer database not found: {db_path}')
    sources=[]; total_size=0; max_total=10*1024*1024
    for path in PROJECT_FILES_DIR.rglob('*'):
        try:
            rel=path.relative_to(PROJECT_FILES_DIR)
            if path.is_symlink() or not path.is_file() or path.suffix.lower() not in SAFE_PROJECT_SUFFIXES: continue
            if any(part.startswith('.') or part.lower() in {'__pycache__','myenv','venv'} or 'backup' in part.lower() for part in rel.parts): continue
            if any(word in path.name.lower() for word in ('backup','secret','token','credential')) or path.stat().st_size>10*1024*1024: continue
            size=path.stat().st_size
            if len(sources)>=30 or total_size+size>max_total: continue
            sources.append(path); total_size+=size
        except (OSError,ValueError): continue
    if not sources: raise FileNotFoundError('No safe project source files found')
    temp_archive=backup_dir/'project-backup.tmp.zip'
    try:
        if temp_archive.is_symlink(): temp_archive.unlink()
        with tempfile.TemporaryDirectory(prefix='.db-snapshot-',dir=backup_dir) as temp_dir:
            snapshot=Path(temp_dir)/db_path.name
            source=sqlite3.connect(db_path.as_uri()+'?mode=ro',uri=True,timeout=30)
            try:
                destination=sqlite3.connect(str(snapshot),timeout=30)
                try: source.backup(destination)
                finally: destination.close()
            finally: source.close()
            with zipfile.ZipFile(temp_archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as zf:
                for path in sorted(sources,key=lambda p:str(p.relative_to(PROJECT_FILES_DIR)).lower()):
                    zf.write(path,arcname=str(path.relative_to(PROJECT_FILES_DIR)))
                zf.write(snapshot,arcname=f'database/{db_path.name}')
        if temp_archive.stat().st_size>49*1024*1024:
            temp_archive.unlink(missing_ok=True)
            raise ValueError('Backup ZIP သည် Telegram ပို့နိုင်သည့်အရွယ်အစားထက် ကြီးနေပါသည်။')
        os.replace(temp_archive,archive)
        return [archive]
    except (OSError,sqlite3.Error,zipfile.BadZipFile,ValueError):
        try: temp_archive.unlink(missing_ok=True)
        except OSError: pass
        log.exception('Could not create project backup archive')
        raise
def project_files_markup(files):
    rows=[[(str(p.relative_to(PROJECT_FILES_DIR))[:55],f'projectfile:{i}')] for i,p in enumerate(files)]
    rows.append([('⬅️ Admin','admin')])
    return kb(rows)
async def send_project_backup(admin_id):
    try:
        files=project_files()
        await bot.send_document(admin_id,FSInputFile(files[0]),caption='📦 Project backup ZIP • backups/project-backup.zip\n✅ Customer, wallet, top-up, order နှင့် key မှတ်တမ်း DB snapshot ပါဝင်ပါသည်။\n⚠️ .env (BOT_TOKEN/FERNET_KEY) မပါပါ။ Server ပြောင်းလျှင် .env ကို သီးခြားလုံခြုံစွာကူးပြီး မူလ FERNET_KEY ကိုမပြောင်းပါနှင့်။ ZIP တွင် customer data ပါသောကြောင့် လုံခြုံစွာသိမ်းပါ။')
        return True
    except Exception as e:
        log.exception('Project backup delivery failed for Admin %s',admin_id)
        try: await bot.send_message(admin_id,f'❌ Customer database ပါသော backup ZIP ဖန်တီး/ပို့မရပါ: {str(e)[:250]}')
        except Exception: pass
        return False
async def edit(q,text,markup=None,parse_mode=None):
    try: await q.message.edit_text(text,reply_markup=markup,parse_mode=parse_mode)
    except Exception: await q.message.answer(text,reply_markup=markup,parse_mode=parse_mode)
def decrypt_panel(r):
    try: password=fernet.decrypt(r['password_enc'].encode()).decode()
    except (InvalidToken,ValueError): raise XUIError('Panel credential ဖွင့်မရပါ။ FERNET_KEY မပြောင်းထားကြောင်းစစ်ပါ။')
    return {'id':r['id'],'name':r['name'],'base_url':r['base_url'],'username':r['username'],'password':password,'share_host':r['share_host'],'enabled':r['enabled']}
def panel_rows(enabled_only=False):
    with db() as c: return c.execute('SELECT * FROM panels'+(' WHERE enabled=1' if enabled_only else '')+' ORDER BY id').fetchall()
def panel_by_id(pid):
    with db() as c: r=c.execute('SELECT * FROM panels WHERE id=?',(pid,)).fetchone()
    if not r: raise XUIError('Panel မတွေ့ပါ။')
    return decrypt_panel(r)
async def client_panel(p): return XUIPanel(p['base_url'],p['username'],p['password'],p['share_host'])
def inb_name(x): return f"#{x.get('id')} {x.get('remark') or x.get('protocol')} • {x.get('protocol')}:{x.get('port')}"
def inbound_picker(inbounds,action_id,panel_id):
    buttons=[]
    for x in inbounds:
        title=inb_name(x)[:55]; buttons.append([(title,f"inb:{action_id}:{panel_id}:{x['id']}")])
    buttons.append([('↩️ ပြန်သွားမည်','admin')]); return kb(buttons)
async def provision(p, iid, uid, plan, months, devices, ref, is_free=False, duration_days=None):
    async with await client_panel(p) as api:
        ins=await api.inbounds()
        inbound=next((i for i in ins if int(i.get('id',-1))==int(iid)),None)
        if not inbound: raise XUIError('ရွေးထားသော inbound ကို panel တွင် မတွေ့ပါ။')
        result=await api.add_client(inbound,uid,months or 0,devices,f'{plan.upper()}-{ref}',duration_days=duration_days)
    result['expiry_text']=datetime.fromtimestamp(result['expiry_ms']/1000,timezone.utc).strftime('%Y-%m-%d %H:%M')
    result['panel_name']=p['name']; result['plan']=plan; result['months']=months; result['days']=duration_days; result['devices']=devices; result['is_free']=is_free
    return result
async def send_client(uid,info,ref):
    term=f'{info["days"]} ရက်' if info.get('days') else f'{info["months"]} လ'
    intro='🎁 Free key ကို မည်သူမဆို မျှဝေသုံးစွဲနိုင်ပါသည်။ တစ်ချိန်တည်း စက် ၁ လုံးသာ ချိတ်ဆက်နိုင်ပါတယ်။' if info.get('is_free') else f"🎉 {html.escape(info['plan'].upper())} plan အတွက် ဝယ်ယူအားပေးမှုကို ကျေးဇူးတင်ပါတယ်။"
    thanks='အသုံးပြုပေးတဲ့အတွက် ကျေးဇူးတင်ပါတယ်။ အသိမိတ်ဆွေတွေကိုလည်း ညွှန်းပေးပါဦးနော်!' if info.get('is_free') else 'ဝယ်ယူအားပေးမှုအတွက် ကျေးဇူးတင်ပါတယ်ဗျ။ အသိမိတ်ဆွေတွေကိုလည်း ညွှန်းပေးပါဦးနော်!'
    text=(f"{intro}\n\n📆 သက်တမ်း: {term}\n📱 Device ကန့်သတ်ချက်: {info['devices']}\n📡 Inbound: {html.escape(str(info['inbound']))}\n⏳ သက်တမ်းကုန်မည့်ရက်: {info['expiry_text']} UTC\n🔗 Subscription link:\n<code>{html.escape(info['subscription_url'])}</code>\n\n😊 {thanks}")
    await bot.send_message(uid,text,parse_mode='HTML')
def log_order_client(oid,uid,pid,iid,info,status='completed'):
    with db() as c: c.execute('UPDATE orders SET panel_id=?,inbound_id=?,client_info=?,status=?,connection_notified=0,first_connected_at=NULL,expiry_reminder_sent=0,expiry_reminder_at=NULL WHERE id=?',(pid,iid,json.dumps(info,ensure_ascii=False),status,oid))

def callback_admin(q): return admin(q.from_user.id)

@dp.message(CommandStart())
async def start(m):
    touch(m.from_user.id,m.from_user.full_name,m.from_user.username,m.from_user.first_name,m.from_user.last_name)
    welcome=(f'💎 <b>LHA ONLINE SERVICE</b>\n'
             f'━━━━━━━━━━━━━━━━━━\n'
             f'မင်္ဂလာပါ {html.escape(m.from_user.first_name or "Customer")} 😊\n'
             f'လုံခြုံပြီး အဆင်ပြေတဲ့ ဝန်ဆောင်မှုမှ ကြိုဆိုပါတယ်။\n\n'
             f'👛 လက်ကျန်ငွေ: <b>{money(balance(m.from_user.id))}</b>\n'
             f'အောက်ပါမီနူးမှ ဝန်ဆောင်မှုကို ရွေးချယ်ပါ။')
    await m.answer(welcome,parse_mode='HTML',reply_markup=main_kb(m.from_user.id))
@dp.message(Command('id'))
async def get_id(m): await m.answer(f'Telegram ID: <code>{m.from_user.id}</code>',parse_mode='HTML')
@dp.callback_query(F.data=='home')
async def home(q): await q.answer(); await edit(q,f'🏠 ပင်မမီနူး\n💰 လက်ကျန်ငွေ: {money(balance(q.from_user.id))}',main_kb(q.from_user.id))
@dp.callback_query(F.data=='balance')
async def show_balance(q):
    with db() as c: rows=c.execute('SELECT delta,note FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT 5',(q.from_user.id,)).fetchall()
    history=[]
    for r in rows:
        note=str(r['note'] or '')
        if note.startswith('Order #'): reason='key ဝယ်ယူမှု • အော်ဒါ '+note.split()[1]
        elif note.startswith('Topup #'): reason='ငွေဖြည့်အတည်ပြု • #'+note.split('#',1)[1]
        elif note.startswith('Refund #'): reason='အော်ဒါငွေပြန်အမ်း • #'+note.split('#',1)[1]
        elif note=='Admin adjustment': reason='Admin မှ လက်ကျန်ငွေပြင်ဆင်မှု'
        else: reason=note or 'လက်ကျန်ငွေပြောင်းလဲမှု'
        sign='➕ ငွေဝင်' if r['delta']>0 else '➖ ငွေနှုတ်'
        history.append(f'{sign} {money(abs(r["delta"]))} — {reason}')
    details='\n'.join(history) if history else 'မှတ်တမ်းမရှိသေးပါ။'
    await q.answer(); await edit(q,f'💰 သင့်လက်ကျန်ငွေ: {money(balance(q.from_user.id))}\n\n🧾 နောက်ဆုံး ငွေဝင်/ငွေနှုတ်မှတ်တမ်း\n{details}',kb([[('➕ ငွေဖြည့်မည်','topup')],[('🏠 ပင်မမီနူး','home')]]))
@dp.callback_query(F.data=='buy')
async def choose_plan(q,state):
    await state.clear()
    text='💎 <b>PREMIUM PLANS</b>\n━━━━━━━━━━━━━━━━━━\n🌏 သင့်အသုံးပြုမည့် Region ကိုရွေးပါ။\n📆 လအရေအတွက်နဲ့ စက်အရေအတွက်ကို နောက်တစ်ဆင့်မှာ ရွေးနိုင်ပါတယ်။'
    if admin(q.from_user.id): text+='\n\n👑 Admin အတွက် JP/SG plan မည်သည့်အမျိုးအစားမဆို အခမဲ့ဖြစ်ပြီး ငွေထည့်ရန် သို့မဟုတ် wallet မှငွေနှုတ်ရန် မလိုပါ။'
    text+='\n\n🔐 လုံခြုံမှု • မြန်ဆန်မှု • ယုံကြည်စိတ်ချရမှု'
    await q.answer(); await edit(q,text,kb([[('🇯🇵 JP • ၄,၅၀၀ ကျပ်','plan_jp'),('🇸🇬 SG • ၅,၅၀၀ ကျပ်','plan_sg')],[('🏠 ပင်မမီနူး','home')]]),parse_mode='HTML')

def number_keyboard(prefix,total,columns,unit):
    rows=[]
    for start in range(1,total+1,columns):
        rows.append([(f'{n} {unit}',f'{prefix}:{n}') for n in range(start,min(total+1,start+columns))])
    rows.append([('❌ မလုပ်တော့ပါ','buy_cancel')])
    return kb(rows)

@dp.callback_query(F.data.startswith('plan_'))
async def select_plan(q,state):
    plan=q.data.split('_',1)[1]
    if plan not in PLANS: return await q.answer('Plan မမှန်ပါ။',show_alert=True)
    await q.answer(); await state.update_data(plan=plan); await state.set_state(Flow.months)
    await edit(q,'📆 သက်တမ်းကို လအရေအတွက်ဖြင့် ခလုပ်မှရွေးပါ။',number_keyboard('month',24,4,'လ'))

@dp.callback_query(F.data=='buy_cancel')
async def cancel_buy_selection(q,state):
    await state.clear(); await q.answer('ရွေးချယ်မှုကို ပယ်ဖျက်ပြီးပါပြီ။')
    await edit(q,'🏠 ပင်မမီနူး',main_kb(q.from_user.id))

@dp.callback_query(F.data.startswith('month:'))
async def select_month_button(q,state):
    if await state.get_state()!=Flow.months.state: return await q.answer('ဒီရွေးချယ်မှု သက်တမ်းကုန်ပါပြီ။ ဝယ်ယူမှုကို ပြန်စပါ။',show_alert=True)
    try: months=int(q.data.split(':',1)[1]); assert 1<=months<=24
    except (ValueError,AssertionError): return await q.answer('သက်တမ်းရွေးချယ်မှု မမှန်ပါ။',show_alert=True)
    await state.update_data(months=months); await state.set_state(Flow.devices); await q.answer()
    await edit(q,f'📱 Device အရေအတွက်ကို ခလုပ်မှရွေးပါ။\nသက်တမ်း: {months} လ',number_keyboard('device',10,5,'စက်'))

async def finalize_order_selection(user_id,full_name,state,devices,send):
    d=await state.get_data(); plan=d.get('plan'); months=int(d.get('months',0))
    if plan not in PLANS or not 1<=months<=24 or not 1<=devices<=10:
        await state.clear(); return await send('ရွေးချယ်မှု သက်တမ်းကုန်/မမှန်ပါ။ ဝယ်ယူမှုကို ပြန်စပါ။')
    list_price=PLANS[plan][1]*months*devices; admin_free=admin(user_id); amount=0 if admin_free else list_price
    current_balance=balance(user_id)
    if not admin_free and current_balance<amount:
        await state.clear()
        return await send(f'ငွေလက်ကျန်မလုံလောက်ပါ။ ငွေမနှုတ်ယူထားပါ။\n{PLANS[plan][0]} • {months} လ • {devices} စက်\nကျသင့်ငွေ: {money(list_price)}\nလက်ကျန်: {money(current_balance)}',reply_markup=kb([[('➕ ငွေဖြည့်မည်','topup')],[('🏠 ပင်မမီနူး','home')]]))
    insufficient=False
    with db() as c:
        if not admin_free:
            # Atomic reservation to prevent simultaneous double spending.
            cur=c.execute('UPDATE users SET balance=balance-? WHERE id=? AND balance>=?',(amount,user_id,amount))
            insufficient=cur.rowcount!=1
        if not insufficient:
            cur=c.execute('INSERT INTO orders(user_id,plan,months,devices,amount,status,created) VALUES(?,?,?,?,?,?,?)',(user_id,plan,months,devices,amount,'awaiting_admin',now())); oid=cur.lastrowid
            if not admin_free: c.execute('INSERT INTO ledger(user_id,delta,note,created) VALUES(?,?,?,?)',(user_id,-amount,f'Order #{oid} reserved',now()))
    if insufficient:
        await state.clear(); return await send('လက်ကျန်ငွေ မလုံလောက်တော့ပါ။ ထပ်စစ်ပြီးဝယ်ပါ။')
    if admin_free:
        notice=f'✅ Admin အခမဲ့အော်ဒါ #{oid} တင်ပြီးပါပြီ။ {PLANS[plan][0]} • {months} လ • {devices} စက်\n💵 ပေးချေရန်မလိုပါ။ Wallet လက်ကျန်မှ ငွေမနှုတ်ပါ။\n💰 လက်ကျန်: {money(balance(user_id))}\nPanel နှင့် inbound ရွေးပြီးနောက် key ကို Admin ဆီပို့ပေးပါမယ်။'
    else:
        notice=f'✅ အော်ဒါ #{oid} တင်ပြီးပါပြီ။ {PLANS[plan][0]} • {months} လ • {devices} စက်\n💵 ကျသင့်ငွေ: {money(amount)}\n➖ နှုတ်ယူရသည့်အကြောင်း: key ဝယ်ယူမှု အော်ဒါ #{oid}\n💰 နှုတ်ယူပြီး လက်ကျန်: {money(balance(user_id))}\nAdmin မှ inbound ရွေးချယ်အတည်ပြုပြီးနောက် key ပို့ပေးပါမယ်။'
    await state.clear(); await send(notice,reply_markup=main_kb(user_id))
    for aid in ADMIN_IDS:
        title='🆓 Admin အခမဲ့အော်ဒါ' if admin_free else '🛒 Customer အော်ဒါ'
        lines=f'{title} #{oid}\nAdmin: {full_name} ({user_id})' if admin_free else f'{title} #{oid}\nCustomer: {full_name} ({user_id})'
        lines+=f'\n{PLANS[plan][0]} • {months} လ • {devices} စက်\n'+('ပေးချေရန်မလိုပါ • Wallet မနှုတ်ပါ' if admin_free else f'ကျသင့်ငွေ {money(amount)}')
        actions=[('📡 Inbound ရွေးပြီး key ထုတ်','order:'+str(oid))]
        await bot.send_message(aid,lines,reply_markup=kb([actions]))

@dp.callback_query(F.data.startswith('device:'))
async def select_device_button(q,state):
    if await state.get_state()!=Flow.devices.state: return await q.answer('ဒီရွေးချယ်မှု သက်တမ်းကုန်ပါပြီ။ ဝယ်ယူမှုကို ပြန်စပါ။',show_alert=True)
    try: devices=int(q.data.split(':',1)[1]); assert 1<=devices<=10
    except (ValueError,AssertionError): return await q.answer('Device ရွေးချယ်မှု မမှန်ပါ။',show_alert=True)
    await q.answer()
    await finalize_order_selection(q.from_user.id,q.from_user.full_name,state,devices,q.message.answer)

@dp.callback_query(F.data=='topup')
async def topup_start(q,state): await q.answer(); await state.set_state(Flow.topup_amount); await edit(q,PAYMENT_INFO+'\n\nအနည်းဆုံး ၁,၀၀၀ ကျပ်ဖြည့်နိုင်ပါတယ်။ ငွေပမာဏကိုပို့ပါ။')
@dp.message(Flow.topup_amount)
async def topup_amount(m,state):
    try: amount=int(m.text.replace(',','')); assert amount>=MIN_TOPUP
    except: return await m.answer('အနည်းဆုံး ၁,၀၀၀ ကျပ်ကို ဂဏန်းဖြင့်ပို့ပါ။')
    await state.update_data(amount=amount); await state.set_state(Flow.topup_proof); await m.answer(f'{money(amount)} လွှဲပြီးနောက် screenshot ဓာတ်ပုံပို့ပါ။')
@dp.message(Flow.topup_proof)
async def topup_proof(m,state):
    if not m.photo: return await m.answer('Screenshot ကို ဓာတ်ပုံအဖြစ်ပို့ပါ။')
    touch(m.from_user.id,m.from_user.full_name,m.from_user.username,m.from_user.first_name,m.from_user.last_name)
    d=await state.get_data();
    with db() as c: cur=c.execute('INSERT INTO topups(user_id,amount,proof_file,created) VALUES(?,?,?,?)',(m.from_user.id,d['amount'],m.photo[-1].file_id,now())); tid=cur.lastrowid
    await state.clear(); await m.answer(f'📨 ငွေဖြည့်တောင်းဆိုမှု #{tid} ပို့ပြီးပါပြီ။ Admin အတည်ပြုပြီးမှ လက်ကျန်ထဲဝင်ပါမယ်။')
    for aid in ADMIN_IDS: await bot.send_photo(aid,photo=m.photo[-1].file_id,caption=f'💳 ငွေဖြည့် #{tid}\nCustomer {m.from_user.full_name} (@{m.from_user.username or "-"})\nID {m.from_user.id}\n{money(d["amount"])}',reply_markup=kb([[('✅ အတည်ပြု','topupok:'+str(tid)),('❌ ပယ်ချ','topupno:'+str(tid))]]))
@dp.callback_query(F.data.startswith('topupok:'))
async def topup_approve(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    tid=int(q.data.split(':')[1])
    with db() as c:
        r=c.execute('SELECT * FROM topups WHERE id=? AND status="pending"',(tid,)).fetchone()
        if not r: return await q.answer('လုပ်ဆောင်ပြီး/မတွေ့ပါ။',show_alert=True)
        c.execute('UPDATE topups SET status="approved" WHERE id=?',(tid,)); c.execute('UPDATE users SET balance=balance+? WHERE id=?',(r['amount'],r['user_id'])); c.execute('INSERT INTO ledger(user_id,delta,note,admin_id,created) VALUES(?,?,?,?,?)',(r['user_id'],r['amount'],f'Topup #{tid}',q.from_user.id,now()))
    await q.answer('အတည်ပြုပြီး'); await q.message.edit_caption((q.message.caption or '')+'\n✅ အတည်ပြု'); await bot.send_message(r['user_id'],f'✅ ငွေဖြည့်အတည်ပြုပြီးပါပြီ။ +{money(r["amount"])}\nလက်ကျန် {money(balance(r["user_id"]))}')
@dp.callback_query(F.data.startswith('topupno:'))
async def topup_reject(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    tid=int(q.data.split(':')[1])
    with db() as c: r=c.execute('SELECT * FROM topups WHERE id=? AND status="pending"',(tid,)).fetchone(); c.execute('UPDATE topups SET status="rejected" WHERE id=? AND status="pending"',(tid,))
    await q.answer('ပယ်ချပြီး');
    if r: await bot.send_message(r['user_id'],f'❌ ငွေဖြည့် #{tid} ကို အတည်မပြုနိုင်ပါ။ ငွေလွှဲအချက်အလက်စစ်ပြီး Admin ကိုဆက်သွယ်ပါ။')

@dp.callback_query(F.data=='admin')
async def admin_home(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    await q.answer(); await edit(q,'👑 <b>ADMIN CONTROL CENTER</b>\n━━━━━━━━━━━━━━━━━━\nPanel, key, customer နှင့် ငွေစာရင်းများကို စီမံနိုင်ပါသည်။',kb([[('📊 အနှစ်ချုပ်','stats'),('🔑 ရောင်းပြီး key','soldkeys')],[('👥 Customer များ','customers'),('💳 ငွေသွင်းမှတ်တမ်း','topuphist')],[('🎁 Redeem code ၅ ခုထုတ်','free'),('🎁 Free key မှတ်တမ်း','freekeys')],[('⏳ ဆိုင်းငံ့ငွေဖြည့်','pendingtop'),('🛒 Pending အော်ဒါ','pendingorders')],[('📡 3x-ui Panel များ','panels'),('💰 Customer ငွေထည့်/နှုတ်','adjust')],[('🔌 Key ချိတ်ဆက်မှတ်တမ်း','connections')],[('🚧 ပြုပြင်ထိန်းသိမ်းမှု','maintenance')],[('📁 Project ဖိုင်ပို့ရန်','projectfiles')],[('🏠 ပင်မမီနူး','home')]]),parse_mode='HTML')

@dp.callback_query(F.data.startswith('connections'))
async def connection_history(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try: offset=max(0,int(q.data.split(':',1)[1])) if ':' in q.data else 0
    except ValueError: offset=0
    with db() as c:
        total=c.execute('SELECT count(*) n FROM connection_events').fetchone()['n']
        rows=c.execute('SELECT * FROM connection_events ORDER BY id DESC LIMIT 10 OFFSET ?',(offset,)).fetchall()
    await q.answer()
    if not rows: return await edit(q,'🔌 Key ချိတ်ဆက်မှတ်တမ်း မရှိသေးပါ။\nမှတ်တမ်းသည် key တစ်ခု ပထမဆုံးချိတ်ဆက်သည့်အချိန်တွင်သာ တစ်ကြိမ်သိမ်းပါသည်။',kb([[('⬅️ Admin','admin')]]))
    text=f'🔌 ပထမဆုံး Key ချိတ်ဆက်မှတ်တမ်း • စုစုပေါင်း {total}\n'
    for r in rows:
        if r['key_type']=='paid':
            who=f'{r["customer_name"] or "အမည်မသိ"} (@{r["username"]})' if r['username'] else (r['customer_name'] or 'အမည်မသိ')
            owner=f'Customer: {who} • Telegram ID {r["customer_id"]}\nOrder #{r["key_id"]}'
        else:
            owner=f'Free key #{r["key_id"]} • ထုတ်ပေးသူ Admin ID {r["issuer_admin_id"] or "-"}\nအသုံးပြုသူ: မသိနိုင်ပါ (shared key)'
        app=r['client_app'] or '3x-ui မှ app အမည်မရရှိပါ'
        text+=(f'\n━━━━━━━━━━━━━━\n{owner} • {r["plan"] or "-"}\n'
               f'Panel: {r["panel_name"] or "-"} • Inbound: {r["inbound"] or "-"}\n'
               f'အချိန်: {r["connected_at"]}\nApp: {app}')
    buttons=[]; nav=[]
    if offset>0: nav.append(('⬅️ ယခင်','connections:'+str(max(0,offset-10))))
    if offset+10<total: nav.append(('နောက်စာမျက်နှာ ➡️','connections:'+str(offset+10)))
    if nav: buttons.append(nav)
    buttons.append([('⬅️ Admin','admin')])
    await edit(q,text,kb(buttons))

MAINTENANCE_NOTICE='🚧 <b>ပြုပြင်ထိန်းသိမ်းမှု အသိပေးချက်</b>\nBot ကို update/ပြုပြင်ရန်အတွက် ခဏရပ်ထားပါသည်။ ဒီအချိန်အတွင်း ဝယ်ယူမှု၊ ငွေဖြည့်မှုနှင့် key ဝန်ဆောင်မှုများ ယာယီမရနိုင်ပါ။ ပြန်လည်အသုံးပြုနိုင်သည်နှင့် ထပ်မံအသိပေးပါမည်။ အော်ဒါ/ငွေလွှဲလုပ်ထားပါက ထပ်မပို့ဘဲ ခဏစောင့်ပေးပါနော်။'
RESUME_NOTICE='✅ <b>ဝန်ဆောင်မှု ပြန်လည်ဖွင့်လှစ်ပါပြီ</b>\nBot ကို ပြန်လည်အသုံးပြုနိုင်ပါပြီ။ ဝယ်ယူမှု၊ ငွေဖြည့်မှုနှင့် key ဝန်ဆောင်မှုများကို ဆက်လက်အသုံးပြုနိုင်ပါပြီ။'
async def broadcast_customers(text):
    with db() as c: ids=[r['id'] for r in c.execute('SELECT id FROM users ORDER BY id').fetchall() if r['id'] not in ADMIN_IDS]
    delivered=failed=0
    for uid in ids:
        try: await bot.send_message(uid,text,parse_mode='HTML'); delivered+=1
        except Exception as e: failed+=1; log.warning('Announcement failed for user %s: %s',uid,e)
        await asyncio.sleep(0.04)
    return delivered,failed
async def set_maintenance(enabled):
    set_setting('maintenance_mode','1' if enabled else '0')
    return await broadcast_customers(MAINTENANCE_NOTICE if enabled else RESUME_NOTICE)

@dp.callback_query(F.data=='maintenance')
async def maintenance_menu(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    status='🚧 Maintenance Mode ဖွင့်ထားသည်' if maintenance_active() else '✅ ပုံမှန်ဝန်ဆောင်မှု လုပ်ဆောင်နေသည်'
    await q.answer(); await edit(q,f'📢 Customer များထံ အမြန်အသိပေးရန်\n{status}\n\nဖွင့်လျှင် customer များကို အကြောင်းကြားပြီး ဝန်ဆောင်မှုကို ခဏပိတ်ထားမည်။ ပြန်ဖွင့်လျှင်လည်း Customer များထံ အသိပေးမည်။',kb([[('🚧 ရပ်ပြီး အသိပေးမည်','maint:on')],[('✅ ပြန်ဖွင့်ပြီး အသိပေးမည်','maint:off')],[('⬅️ Admin','admin')]]))

@dp.callback_query(F.data=='maint:on')
async def maintenance_enable_callback(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    if maintenance_active(): return await q.answer('Maintenance Mode ဖွင့်ထားပြီးပါပြီ။',show_alert=True)
    await q.answer('Customer များထံ အသိပေးနေသည်…')
    delivered,failed=await set_maintenance(True)
    await edit(q,f'🚧 Maintenance Mode ဖွင့်ပြီးပါပြီ။\nအသိပေးပို့ပြီး: {delivered} ယောက် • မပို့နိုင်: {failed} ယောက်',kb([[('✅ ပြန်ဖွင့်ပြီး အသိပေးမည်','maint:off')],[('⬅️ Admin','admin')]]))

@dp.callback_query(F.data=='maint:off')
async def maintenance_disable_callback(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    if not maintenance_active(): return await q.answer('Maintenance Mode ပိတ်ထားပြီးပါပြီ။',show_alert=True)
    await q.answer('ဝန်ဆောင်မှုပြန်ဖွင့်ကြောင်း အသိပေးနေသည်…')
    delivered,failed=await set_maintenance(False)
    await edit(q,f'✅ ဝန်ဆောင်မှု ပြန်ဖွင့်ပြီးပါပြီ။\nအသိပေးပို့ပြီး: {delivered} ယောက် • မပို့နိုင်: {failed} ယောက်',kb([[('🚧 Maintenance ပြန်ဖွင့်ရန်','maint:on')],[('⬅️ Admin','admin')]]))

@dp.message(Command('maint_on'))
async def maintenance_enable_command(m):
    if not admin(m.from_user.id): return await m.answer('Admin သာအသုံးပြုနိုင်ပါသည်။')
    if maintenance_active(): return await m.answer('Maintenance Mode ဖွင့်ထားပြီးပါပြီ။')
    await m.answer('Customer များထံ အသိပေးနေပြီး ဝန်ဆောင်မှုကို ခဏရပ်နေပါသည်…')
    delivered,failed=await set_maintenance(True)
    await m.answer(f'🚧 Maintenance Mode ဖွင့်ပြီးပါပြီ။ ပို့ပြီး {delivered} ယောက် • မပို့နိုင် {failed} ယောက်')

@dp.message(Command('maint_off'))
async def maintenance_disable_command(m):
    if not admin(m.from_user.id): return await m.answer('Admin သာအသုံးပြုနိုင်ပါသည်။')
    if not maintenance_active(): return await m.answer('Maintenance Mode ပိတ်ထားပြီးပါပြီ။')
    await m.answer('ဝန်ဆောင်မှု ပြန်ဖွင့်ကြောင်း Customer များကို အသိပေးနေသည်…')
    delivered,failed=await set_maintenance(False)
    await m.answer(f'✅ ဝန်ဆောင်မှု ပြန်ဖွင့်ပြီးပါပြီ။ ပို့ပြီး {delivered} ယောက် • မပို့နိုင် {failed} ယောက်')

@dp.message(Command('files'))
async def project_files_command(m):
    if not admin(m.from_user.id): return await m.answer('Admin သာအသုံးပြုနိုင်ပါသည်။')
    await m.answer('📦 Project backup ဖိုင် ပြင်ဆင်ပြီး ပို့နေပါသည်…')
    await send_project_backup(m.from_user.id)

@dp.callback_query(F.data=='projectfiles')
async def project_files_menu(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    await q.answer('Backup ဖိုင်ပို့နေပါသည်…')
    await send_project_backup(q.from_user.id)

@dp.callback_query(F.data.startswith('projectfile:'))
async def send_project_file(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try: idx=int(q.data.split(':',1)[1]); files=project_files(); path=files[idx]
    except (ValueError,IndexError): return await q.answer('ဖိုင်ကို ပြန်ရွေးပါ။',show_alert=True)
    except Exception as e:
        log.exception('Could not regenerate project backup for Admin %s',q.from_user.id)
        return await q.answer(f'Backup မဖန်တီးနိုင်ပါ: {str(e)[:180]}',show_alert=True)
    await q.answer('ဖိုင်ပို့နေသည်…')
    try: await bot.send_document(q.from_user.id,FSInputFile(path),caption=f'Project backup: {path.relative_to(PROJECT_FILES_DIR)}')
    except Exception as e:
        log.exception('Project backup delivery failed for Admin %s',q.from_user.id)
        await q.message.answer(f'❌ ဖိုင်ပို့မရပါ: {str(e)[:250]}')

@dp.callback_query(F.data=='stats')
async def stats(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    with db() as c: u=c.execute('SELECT count(*) n FROM users').fetchone()['n']; top=c.execute('SELECT count(*) n FROM topups WHERE status="pending"').fetchone()['n']; o=c.execute('SELECT count(*) n FROM orders WHERE status="awaiting_admin"').fetchone()['n']; sale=c.execute('SELECT coalesce(sum(amount),0) n FROM orders WHERE status="completed"').fetchone()['n']; free=c.execute('SELECT count(*) n FROM free_keys WHERE deleted_at IS NULL').fetchone()['n']
    await q.answer(); await edit(q,f'📊 အသုံးပြုသူ {u}\nစောင့်ဆိုင်း ငွေဖြည့် {top}\nစောင့်ဆိုင်း အော်ဒါ {o}\nပြီးစီးရောင်းအား {money(sale)}\nFree key {free}',kb([[('⬅️ Admin','admin')]]))
@dp.callback_query(F.data.startswith('customers'))
async def customer_list(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try: offset=max(0,int(q.data.split(':',1)[1])) if ':' in q.data else 0
    except ValueError: offset=0
    with db() as c:
        total=c.execute('SELECT count(*) n FROM users').fetchone()['n']
        rows=c.execute('SELECT id,name,username,balance FROM users ORDER BY created DESC,id DESC LIMIT 10 OFFSET ?',(offset,)).fetchall()
    await q.answer()
    if not rows: return await edit(q,'Customer မရှိသေးပါ။',kb([[('⬅️ Admin','admin')]]))
    buttons=[]
    for r in rows:
        label=f'{r["name"] or "အမည်မရှိ"} • @{r["username"]}' if r['username'] else f'{r["name"] or "အမည်မရှိ"} • ID {r["id"]}'
        buttons.append([(label[:55],f'cust:{r["id"]}')])
    nav=[]
    if offset>0: nav.append(('⬅️ ယခင်','customers:'+str(max(0,offset-10))))
    if offset+10<total: nav.append(('နောက်စာမျက်နှာ ➡️','customers:'+str(offset+10)))
    if nav: buttons.append(nav)
    buttons.append([('⬅️ Admin','admin')])
    await edit(q,f'👥 Customer စာရင်း • စုစုပေါင်း {total} ယောက်\nစာမျက်နှာ {offset//10+1}\nCustomer ကိုနှိပ်ပြီး အကောင့်အသေးစိတ်ကြည့်ပါ။',kb(buttons))

@dp.callback_query(F.data.startswith('cust:'))
async def customer_detail(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try: uid=int(q.data.split(':',1)[1])
    except ValueError: return await q.answer('Customer ID မမှန်ပါ။',show_alert=True)
    with db() as c:
        u=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
        if not u: return await q.answer('Customer မတွေ့ပါ။',show_alert=True)
        tops=c.execute('SELECT status,count(*) n,coalesce(sum(amount),0) amount FROM topups WHERE user_id=? GROUP BY status',(uid,)).fetchall()
        orders=c.execute('SELECT status,count(*) n,coalesce(sum(amount),0) amount FROM orders WHERE user_id=? GROUP BY status',(uid,)).fetchall()
        recent_top=c.execute('SELECT id,amount,status,created FROM topups WHERE user_id=? ORDER BY id DESC LIMIT 5',(uid,)).fetchall()
        recent_orders=c.execute('SELECT id,plan,months,devices,amount,status,created,deleted_at FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 5',(uid,)).fetchall()
        frees=c.execute('SELECT count(*) n FROM free_keys WHERE user_id=? AND deleted_at IS NULL',(uid,)).fetchone()['n']
    topmap={r['status']:r for r in tops}; ordermap={r['status']:r for r in orders}
    approved=topmap.get('approved'); pending=topmap.get('pending')
    completed=ordermap.get('completed')
    username='@'+u['username'] if u['username'] else 'မရှိ/မသိမ်းရသေးပါ'
    first_last=' '.join(x for x in (u['first_name'],u['last_name']) if x) or u['name'] or '-'
    text=(f'👤 Customer အကောင့်အသေးစိတ်\nအမည်: {u["name"] or "-"}\nပထမ/နောက်ဆုံးအမည်: {first_last}\nTelegram username: {username}\nTelegram ID: {uid}\nအကောင့်ဖွင့်ရက်: {u["created"]}\nလက်ကျန်ငွေ: {money(u["balance"])}\n\n'
          f'💳 အတည်ပြုပြီးငွေသွင်း: {approved["n"] if approved else 0} ကြိမ် • {money(approved["amount"] if approved else 0)}\n'
          f'⏳ ဆိုင်းငံ့ငွေသွင်း: {pending["n"] if pending else 0} ကြိမ် • {money(pending["amount"] if pending else 0)}\n'
          f'🛒 အောင်မြင်ဝယ်ယူမှု: {completed["n"] if completed else 0} ကြိမ် • {money(completed["amount"] if completed else 0)}\n'
          f'🎁 Free key မှတ်တမ်း: {frees} ခု\n\nငွေသွင်းမှတ်တမ်း နောက်ဆုံး ၅ ခု:')
    for r in recent_top: text+=f'\n• #{r["id"]} {money(r["amount"])} • {r["status"]} • {r["created"][:10]}'
    if not recent_top: text+='\n• မှတ်တမ်းမရှိပါ။'
    text+='\n\nအော်ဒါမှတ်တမ်း နောက်ဆုံး ၅ ခု:'
    for r in recent_orders: text+=f'\n• #{r["id"]} {r["plan"].upper()} {r["months"]}လ/{r["devices"]}စက် • {money(r["amount"])} • {"Key ဖျက်ပြီး" if r["deleted_at"] else r["status"]}'
    if not recent_orders: text+='\n• အော်ဒါမရှိပါ။'
    until=active_pause(uid)
    pause_line=f'⏸️ Customer ကို ခဏရပ်ထားသည် ({until.strftime("%Y-%m-%d %H:%M UTC")})' if until else '✅ Customer အသုံးပြုခွင့် ဖွင့်ထားသည်'
    text+='\n\n'+pause_line
    pause_button=('▶️ Customer ပြန်ဖွင့်ရန်',f'custresume:{uid}') if until else ('⏸️ Customer ကို ခဏရပ်ရန်',f'custpause:{uid}')
    await q.answer()
    await edit(q,text,kb([[pause_button],[('➕/➖ လက်ကျန်ပြင်ရန်',f'adjcust:{uid}')],[('⬅️ Customer စာရင်း','customers')],[('⬅️ Admin','admin')]]))

@dp.callback_query(F.data.startswith('custpause:'))
async def customer_pause_menu(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try: uid=int(q.data.split(':',1)[1])
    except ValueError: return await q.answer('Customer ID မမှန်ပါ။',show_alert=True)
    with db() as c: exists=c.execute('SELECT 1 FROM users WHERE id=?',(uid,)).fetchone()
    if not exists: return await q.answer('Customer မတွေ့ပါ။',show_alert=True)
    await q.answer(); await edit(q,f'Customer {uid} ကို ဘယ်လောက်ကြာ ခဏရပ်ထားမလဲ?',kb([[('၁၀ မိနစ်','custpausefor:'+str(uid)+':10'),('၁ နာရီ','custpausefor:'+str(uid)+':60')],[('၆ နာရီ','custpausefor:'+str(uid)+':360'),('၂၄ နာရီ','custpausefor:'+str(uid)+':1440')],[('⬅️ အကောင့်သို့ပြန်','cust:'+str(uid))]]))

@dp.callback_query(F.data.startswith('custpausefor:'))
async def customer_pause_apply(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try: _,uid_s,minutes_s=q.data.split(':'); uid=int(uid_s); minutes=int(minutes_s)
    except ValueError: return await q.answer('အချက်အလက်မမှန်ပါ။',show_alert=True)
    if minutes not in (10,60,360,1440): return await q.answer('ရပ်ထားမည့်ကြာချိန် မမှန်ပါ။',show_alert=True)
    with db() as c: u=c.execute('SELECT name FROM users WHERE id=?',(uid,)).fetchone()
    if not u: return await q.answer('Customer မတွေ့ပါ။',show_alert=True)
    until=pause_customer(uid,minutes,u['name'] or 'Customer')
    await q.answer('Customer ကို ယာယီရပ်ထားပါပြီ။')
    try: await bot.send_message(uid,f'⏸️ Admin မှ သင့် bot အသုံးပြုခွင့်ကို ယာယီရပ်ထားပါသည်။ ပြန်အသုံးပြုနိုင်မည့်အချိန်: {until.strftime("%Y-%m-%d %H:%M UTC")}')
    except Exception as e: log.warning('Could not notify paused customer %s: %s',uid,e)
    await edit(q,f'⏸️ Customer {uid} ကို {minutes} မိနစ် ခဏရပ်ထားပါပြီ။\nပြန်ဖွင့်မည့်အချိန်: {until.strftime("%Y-%m-%d %H:%M UTC")}',kb([[('▶️ Customer ပြန်ဖွင့်ရန်',f'custresume:{uid}')],[('👤 အကောင့်အသေးစိတ်','cust:'+str(uid))],[('⬅️ Customer စာရင်း','customers')]]))

@dp.callback_query(F.data.startswith('custresume:'))
async def customer_resume(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try: uid=int(q.data.split(':',1)[1])
    except ValueError: return await q.answer('Customer ID မမှန်ပါ။',show_alert=True)
    if not resume_customer(uid): return await q.answer('Customer မတွေ့ပါ။',show_alert=True)
    await q.answer('Customer အသုံးပြုခွင့် ပြန်ဖွင့်ပြီးပါပြီ။')
    try: await bot.send_message(uid,'✅ သင့် bot အသုံးပြုခွင့်ကို Admin မှ ပြန်ဖွင့်ပေးလိုက်ပါပြီ။')
    except Exception as e: log.warning('Could not notify resumed customer %s: %s',uid,e)
    await edit(q,f'✅ Customer {uid} အသုံးပြုခွင့်ကို ပြန်ဖွင့်ပြီးပါပြီ။',kb([[('👤 အကောင့်အသေးစိတ်',f'cust:{uid}')],[('⬅️ Customer စာရင်း','customers')]]))

@dp.callback_query(F.data.startswith('adjcust:'))
async def adjust_customer_start(q,state):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    uid=int(q.data.split(':',1)[1]); await state.update_data(target_uid=uid); await state.set_state(Flow.admin_amount)
    await q.answer(); await q.message.answer(f'Customer ID {uid} အတွက် ငွေပမာဏပို့ပါ။\nထည့်ရန် 5000၊ နှုတ်ရန် -5000 ဟု ပို့ပါ။')

@dp.callback_query(F.data=='topuphist')
async def topup_history(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    with db() as c:
        rows=c.execute('''SELECT t.*,u.name,u.username FROM topups t LEFT JOIN users u ON u.id=t.user_id ORDER BY t.id DESC LIMIT 20''').fetchall()
    await q.answer()
    if not rows: return await edit(q,'ငွေသွင်းမှတ်တမ်း မရှိသေးပါ။',kb([[('⬅️ Admin','admin')]]))
    await edit(q,'💳 ငွေသွင်းမှတ်တမ်း • နောက်ဆုံး ၂၀ ခု')
    for r in rows:
        who=f'{r["name"] or "အမည်မရှိ"} (@{r["username"]})' if r['username'] else f'{r["name"] or "အမည်မရှိ"} • ID {r["user_id"]}'
        caption=f'💳 ငွေဖြည့် #{r["id"]}\nCustomer: {who}\nTelegram ID: {r["user_id"]}\nပမာဏ: {money(r["amount"])}\nအခြေအနေ: {r["status"]}\nရက်စွဲ: {r["created"]}'
        markup=kb([[('✅ အတည်ပြု','topupok:'+str(r['id'])),('❌ ပယ်ချ','topupno:'+str(r['id']))]]) if r['status']=='pending' else None
        if r['proof_file']: await bot.send_photo(q.from_user.id,photo=r['proof_file'],caption=caption,reply_markup=markup)
        else: await bot.send_message(q.from_user.id,caption,reply_markup=markup)
    await q.message.answer('Admin မီနူး',reply_markup=kb([[('⬅️ Admin','admin')]]))

@dp.callback_query(F.data=='pendingtop')
async def pendingtop(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    with db() as c: rows=c.execute('SELECT t.*,u.name,u.username FROM topups t LEFT JOIN users u ON u.id=t.user_id WHERE t.status="pending" ORDER BY t.id').fetchall()
    await q.answer()
    if not rows: return await edit(q,'ဆိုင်းငံ့ငွေဖြည့်မရှိပါ။',kb([[('⬅️ Admin','admin')]]))
    for r in rows:
        await q.message.answer(f'💳 #{r["id"]} • {r["name"] or "အမည်မရှိ"} (@{r["username"] or "-"}) • ID {r["user_id"]} • {money(r["amount"])}')
        if r['proof_file']: await bot.send_photo(q.from_user.id,photo=r['proof_file'],reply_markup=kb([[('✅ အတည်ပြု','topupok:'+str(r['id'])),('❌ ပယ်ချ','topupno:'+str(r['id']))]]))
@dp.callback_query(F.data=='pendingorders')
async def pendingorders(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    with db() as c: rows=c.execute('SELECT * FROM orders WHERE status="awaiting_admin" ORDER BY id').fetchall()
    await q.answer()
    if not rows: return await edit(q,'ဆိုင်းငံ့အော်ဒါမရှိပါ။',kb([[('⬅️ Admin','admin')]]))
    for r in rows: await q.message.answer(f'🛒 #{r["id"]} • customer {r["user_id"]}\n{PLANS[r["plan"]][0]} • {r["months"]}လ • {r["devices"]}စက် • {money(r["amount"])}',reply_markup=kb([[('📡 Inbound ရွေး','order:'+str(r['id']))]]))

@dp.callback_query(F.data=='panels')
async def panels_menu(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    rows=panel_rows(); await q.answer()
    text='📡 Panel စာရင်း\n'+('\n'.join(f'#{r["id"]} • {r["name"]} • {r["base_url"]} • {"ဖွင့်" if r["enabled"] else "ပိတ်"}' for r in rows) if rows else 'Panel မထည့်ရသေးပါ။')
    buttons=[[('➕ Panel အသစ်ထည့်','paneladd')]]
    for r in rows:
        buttons.append([(f'🧪 စစ်ဆေး {r["name"]}'[:50],f'paneltest:{r["id"]}'),(f'{"ပိတ်" if r["enabled"] else "ဖွင့်"} #{r["id"]}',f'paneltoggle:{r["id"]}')])
        buttons.append([(f'🗑️ Panel #{r["id"]} bot မှဖယ်ရန်',f'paneldelete:{r["id"]}')])
    buttons.append([('⬅️ Admin','admin')]); await edit(q,text,kb(buttons))
@dp.callback_query(F.data=='paneladd')
async def panel_add_start(q,state):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    await q.answer(); await state.set_state(Flow.panel_name); await q.message.answer('Panel အမည်ပို့ပါ။ ဥပမာ JP-1')
@dp.message(Flow.panel_name)
async def panel_name(m,state): await state.update_data(pname=m.text.strip()[:50]); await state.set_state(Flow.panel_url); await m.answer('Panel URL အပြည့်အစုံပို့ပါ။ ဥပမာ https://panel.example.com/secretpath (နောက်ဆုံး slash မပါလည်းရ)')
@dp.message(Flow.panel_url)
async def panel_url(m,state):
    url=m.text.strip().rstrip('/')
    if not url.startswith('https://'): return await m.answer('လုံခြုံရေးအတွက် https:// URL ကိုသာသုံးပါ။ URL ကိုပြန်ပို့ပါ။')
    await state.update_data(purl=url); await state.set_state(Flow.panel_user); await m.answer('3x-ui username ပို့ပါ။')
@dp.message(Flow.panel_user)
async def panel_user(m,state): await state.update_data(puser=m.text.strip()); await state.set_state(Flow.panel_pass); await m.answer('3x-ui password ကိုပို့ပါ။ Bot က လက်ခံပြီးနောက် ဒီ message ကို chat မှ ဖျက်ရန်ကြိုးစားပါမယ်။')
@dp.message(Flow.panel_pass)
async def panel_pass(m,state):
    await state.update_data(ppass=m.text); await state.set_state(Flow.panel_host)
    try: await m.delete()
    except: pass
    await m.answer('Customer ချိတ်ဆက်မည့် server host/IP ကိုထည့်ပါ။ Panel domain နဲ့ မတူနိုင်ပါ။ တူညီပါက “same” ဟုရေးပါ။')
@dp.message(Flow.panel_host)
async def panel_host(m,state):
    d=await state.get_data(); host=None if m.text.strip().lower()=='same' else m.text.strip()
    if host and any(ch in host for ch in '/ @?#'): return await m.answer('Domain သို့မဟုတ် IP သာ ထည့်ပေးပါ။')
    pending={'name':d['pname'],'base_url':d['purl'],'username':d['puser'],'password':d['ppass'],'share_host':host or None}
    try:
        async with await client_panel(pending) as api: ins=await api.inbounds()
        token=fernet.encrypt(pending['password'].encode()).decode()
        with db() as c: cur=c.execute('INSERT INTO panels(name,base_url,username,password_enc,share_host,created) VALUES(?,?,?,?,?,?)',(pending['name'],pending['base_url'],pending['username'],token,pending['share_host'],now())); pid=cur.lastrowid
        await m.answer(f'✅ Panel ချိတ်ဆက်မှုအောင်မြင်ပါသည်။ Panel #{pid} သိမ်းပြီးပါပြီ။ Inbound {len(ins)} ခု တွေ့ရှိသည်။',reply_markup=kb([[('📡 Panel များ','panels')],[('🛠️ Admin','admin')]]))
    except Exception as e: await m.answer(f'❌ Panel ထည့်မရပါ: {str(e)[:500]}\nCredential ကို မသိမ်းထားပါ။ ထပ်စစ်ပြီး panel အသစ်ထည့်ပါ။',reply_markup=kb([[('📡 Panel များ','panels')]]))
    finally: await state.clear()
@dp.callback_query(F.data.startswith('paneltest:'))
async def panel_test(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    pid=int(q.data.split(':')[1]); await q.answer('စစ်ဆေးနေသည်…')
    try:
        p=panel_by_id(pid)
        async with await client_panel(p) as api: ins=await api.inbounds()
        await q.message.answer(f'✅ {p["name"]} ချိတ်ဆက်မှုအောင်မြင်။ Inbound {len(ins)} ခု။')
    except Exception as e: await q.message.answer(f'❌ Panel စစ်ဆေးမအောင်မြင်: {str(e)[:400]}')
@dp.callback_query(F.data.startswith('paneltoggle:'))
async def panel_toggle(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    pid=int(q.data.split(':')[1])
    with db() as c: c.execute('UPDATE panels SET enabled=1-enabled WHERE id=?',(pid,))
    await q.answer('ပြောင်းလဲပြီး'); await panels_menu(q)

def panel_key_usage(pid):
    with db() as c:
        paid=c.execute('SELECT count(*) n FROM orders WHERE panel_id=? AND client_info IS NOT NULL',(pid,)).fetchone()['n']
        free=c.execute('SELECT count(*) n FROM free_keys WHERE panel_id=? AND client_info IS NOT NULL',(pid,)).fetchone()['n']
    return paid+free

@dp.callback_query(F.data.startswith('paneldelete:'))
async def panel_delete_start(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try: pid=int(q.data.split(':',1)[1])
    except ValueError: return await q.answer('Panel ID မမှန်ပါ။',show_alert=True)
    # Deletion only removes the saved panel row. Do not decrypt credentials
    # here: an old record must remain removable even if FERNET_KEY changed.
    with db() as c: p=c.execute('SELECT id,name FROM panels WHERE id=?',(pid,)).fetchone()
    if not p: return await q.answer('ဒီ Panel မှတ်တမ်းကို database ထဲမှာ မတွေ့ပါ။ Panel စာရင်းကို ပြန်ဖွင့်ပြီး ထပ်စမ်းပါ။',show_alert=True)
    used=panel_key_usage(pid); await q.answer()
    linked=(f'⚠️ ဒီ panel နဲ့ key မှတ်တမ်း {used} ခု ချိတ်ထားပါတယ်။ ဖယ်ရှားပြီးလျှင် အဲဒီ key များကို bot မှ ပိတ်/ပြန်ဖွင့်မရတော့ပါ။ Panel ကို bot ထဲ ပြန်ထည့်မှသာ စီမံနိုင်ပါမယ်.\n' if used else '')
    await q.message.answer(f'{linked}Panel #{pid} • {p["name"]} ကို bot ထဲမှဖယ်ရှားမလား?\nဖယ်ရှားခြင်းက bot ထဲသိမ်းထားတဲ့ URL/login ကိုသာ ဖျက်ပါမယ်။ 3x-ui server နဲ့ ရှိပြီးသား client များကို မဖျက်ပါ။',reply_markup=kb([[('🗑️ အတည်ပြုပြီးဖယ်ရှားမည်',f'paneldeleteconfirm:{pid}')],[('မဖျက်တော့ပါ','panels')]]))

@dp.callback_query(F.data.startswith('paneldeleteconfirm:'))
async def panel_delete_confirm(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try: pid=int(q.data.split(':',1)[1])
    except ValueError: return await q.answer('Panel ID မမှန်ပါ။',show_alert=True)
    used=panel_key_usage(pid)
    with db() as c: cur=c.execute('DELETE FROM panels WHERE id=?',(pid,))
    if cur.rowcount!=1: return await q.answer('Panel မတွေ့ပါ။',show_alert=True)
    await q.answer('Bot မှဖယ်ရှားပြီးပါပြီ။')
    note=f' Key မှတ်တမ်း {used} ခုအတွက် bot မှ ပိတ်/ပြန်ဖွင့်မလုပ်နိုင်တော့ပါ; panel ကို ပြန်ထည့်ပါ.' if used else ''
    await q.message.edit_text(f'✅ Panel #{pid} ကို bot ထဲမှဖယ်ရှားပြီးပါပြီ။{note}\n3x-ui server နဲ့ client များကို မဖျက်ထားပါ။',reply_markup=kb([[('📡 Panel စာရင်း','panels')],[('⬅️ Admin','admin')]]))

@dp.callback_query(F.data.startswith('order:'))
async def order_choose_panel(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    oid=int(q.data.split(':')[1])
    with db() as c: r=c.execute('SELECT * FROM orders WHERE id=? AND status="awaiting_admin"',(oid,)).fetchone()
    ps=panel_rows(True); await q.answer()
    if not r: return await q.message.answer('အော်ဒါ မရှိပါ သို့မဟုတ် လုပ်ဆောင်ပြီးပါပြီ။')
    if not ps: return await q.message.answer('Panel မရှိသေးပါ။ Admin > Panel များမှ ထည့်ပါ။')
    with db() as c: notified=c.execute('UPDATE orders SET waiting_notified=1 WHERE id=? AND status="awaiting_admin" AND waiting_notified=0',(oid,)).rowcount==1
    if notified:
        try: await bot.send_message(r['user_id'],f'🕒 အော်ဒါ #{oid} အတွက် Admin က panel နှင့် inbound ရွေးချယ်နေပါပြီ။ ခဏစောင့်ပေးပါနော်။ Key ပြင်ဆင်ပြီးတာနဲ့ ဒီ bot ကနေ ပို့ပေးပါမယ်။')
        except Exception as e: log.warning('Could not send order wait notice to %s: %s',r['user_id'],e)
    await q.message.answer(f'အော်ဒါ #{oid} အတွက် Panel ရွေးပါ။',reply_markup=kb([[(p['name'],f'pickpanel:order:{oid}:{p["id"]}')] for p in ps]))
@dp.callback_query(F.data.startswith('pickpanel:'))
async def pick_panel(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    _,typ,ref,pid=q.data.split(':'); pid=int(pid); await q.answer('Inbound စာရင်းရယူနေသည်…')
    try:
        p=panel_by_id(pid)
        async with await client_panel(p) as api: ins=await api.inbounds()
        # Pack action reference into callback; IDs are small integers.
        if not ins: return await q.message.answer('ဒီ panel မှာ inbound မရှိပါ။')
        action=f'o{ref}' if typ=='order' else (f'b{ref}' if typ=='batch' else f'f{ref}')
        await q.message.answer(f'{p["name"]} မှ inbound ရွေးပါ။',reply_markup=inbound_picker(ins,action,pid))
    except Exception as e: await q.message.answer(f'❌ Inbound ရယူမရပါ: {str(e)[:400]}')
@dp.callback_query(F.data.startswith('inb:'))
async def pick_inbound(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    _,action,pid_s,iid_s=q.data.split(':'); pid=int(pid_s); iid=int(iid_s); await q.answer('စစ်ဆေးနေသည်…')
    try:
        p=panel_by_id(pid)
        if action.startswith('o'):
            oid=int(action[1:])
            with db() as c: r=c.execute('SELECT * FROM orders WHERE id=? AND status="awaiting_admin"',(oid,)).fetchone()
            if not r: return await q.message.answer('အော်ဒါပြီးစီးပြီး/မတွေ့ပါ။')
            with db() as c:
                claimed=c.execute('UPDATE orders SET status="provisioning" WHERE id=? AND status="awaiting_admin"',(oid,))
                if claimed.rowcount != 1: return await q.message.answer('ဒီအော်ဒါကို အခြားလုပ်ဆောင်မှုတစ်ခုက စတင်ထားပြီးပါပြီ။')
            try:
                info=await provision(p,iid,r['user_id'],r['plan'],r['months'],r['devices'],str(oid))
                log_order_client(oid,r['user_id'],pid,iid,info)
                await send_client(r['user_id'],info,oid)
                await q.message.answer(f'✅ အော်ဒါ #{oid} client ဖန်တီးပြီး customer ဆီပို့ပြီးပါပြီ။\n{info["inbound"]} • {info["expiry_text"]}')
            except Exception as e:
                with db() as c: c.execute('UPDATE orders SET status="awaiting_admin" WHERE id=? AND status="provisioning"',(oid,))
                raise e
        elif action.startswith('b'):
            batch_id=action[1:]
            with db() as c:
                rows=c.execute('''SELECT r.code,r.free_key_id FROM redeem_codes r JOIN free_keys f ON f.id=r.free_key_id
                    WHERE r.batch_id=? AND r.used_by IS NULL AND f.client_info IS NULL AND f.deleted_at IS NULL ORDER BY r.free_key_id''',(batch_id,)).fetchall()
                if not rows: return await q.message.answer('Redeem code batch မတွေ့ပါ။')
                changed=c.execute('''UPDATE free_keys SET panel_id=?,inbound_id=? WHERE id IN (SELECT free_key_id FROM redeem_codes WHERE batch_id=? AND used_by IS NULL) AND client_info IS NULL AND deleted_at IS NULL''',(pid,iid,batch_id)).rowcount
            codes='\n'.join(f'• {r["code"]}' for r in rows)
            await q.message.answer(f'✅ Redeem code ၅ ခု အသင့်ဖြစ်ပါပြီ။ Customer တစ်ယောက်စီက code တစ်ခုထည့်မှသာ key ရပါမယ်။\n\n{codes}')
        else:
            freeid=int(action[1:])
            with db() as c:
                r=c.execute('SELECT * FROM free_keys WHERE id=? AND client_info IS NULL AND deleted_at IS NULL',(freeid,)).fetchone()
                code_row=c.execute('SELECT code FROM redeem_codes WHERE free_key_id=? AND used_by IS NULL',(freeid,)).fetchone()
                if not r: return await q.message.answer('Free redeem request မတွေ့ပါ။')
                if not code_row: return await q.message.answer('Redeem code မတွေ့ပါ သို့မဟုတ် အသုံးပြုပြီးပါပြီ။')
                changed=c.execute('UPDATE free_keys SET panel_id=?,inbound_id=? WHERE id=? AND client_info IS NULL AND deleted_at IS NULL',(pid,iid,freeid)).rowcount
            if changed!=1: return await q.message.answer('ဒီ redeem code ကို အခြားလုပ်ဆောင်မှုက ပြင်ဆင်နေပါသည်။')
            await q.message.answer(f'✅ Redeem code `{code_row["code"]}` အသင့်ဖြစ်ပါပြီ။ Customer က ဒီ code ကို bot ထဲထည့်မှသာ Free key ကို 3x-ui မှာဖန်တီးပြီး Customer ဆီပို့ပါမယ်။',parse_mode='Markdown')
    except Exception as e: await q.message.answer(f'❌ Key ထုတ်မရပါ: {str(e)[:600]}')

@dp.callback_query(F.data.startswith('refund:'))
async def disabled_refund_callback(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    await q.answer('ငွေပြန်အမ်းလုပ်ဆောင်ချက်ကို ပိတ်ထားပါသည်။ Wallet လက်ကျန် မပြောင်းလဲပါ။',show_alert=True)

def create_free_request(admin_id):
    with db() as c:
        cur=c.execute('INSERT INTO free_keys(admin_id,user_id,created) VALUES(?,?,?)',(admin_id,0,now()))
        return cur.lastrowid

async def begin_free_key(admin_id,state,send):
    await state.clear()
    freeid=create_free_request(admin_id)
    await state.update_data(freeid=freeid,freeuid=0)
    await state.set_state(Flow.free_plan)
    await send('🎁 လူမရွေးအသုံးပြုနိုင်သော Free key ထုတ်ရန် JP သို့မဟုတ် SG ကိုရွေးပါ။ နောက်တစ်ဆင့်တွင် သက်တမ်းရက်ကို ခလုပ်ဖြင့်ရွေးနိုင်ပါသည်။',reply_markup=kb([[('🇯🇵 JP','freeplan:jp'),('🇸🇬 SG','freeplan:sg')]]))

@dp.message(Command('freekey'))
async def free_key_command(m,state):
    await m.answer('အသုံးပြုပုံ: Admin က /redeem FREE-ABC123 ဟု ပို့ပြီး redeem code ဖန်တီးပါ။ Customer က ထို code ကို bot ထဲပို့မှသာ Free key ရပါမည်။')

@dp.message(Command('redeem'))
async def redeem_free_key_command(m,state):
    parts=(m.text or '').split(maxsplit=1)
    if not admin(m.from_user.id):
        if len(parts)!=2: return await m.answer('Redeem code ထည့်ပါ။ ဥပမာ: /redeem FREE-ABC123')
        return await redeem_customer_code(m,parts[1].strip())
    if len(parts)!=2 or parts[1].strip().upper()!='GENERATED':
        return await m.answer('အသုံးပြုပုံ: /redeem GENERATED\nBot က customer redeem code ၅ ခု ထုတ်ပေးပါမယ်။')
    await state.clear()
    await state.update_data(redeem_batch=True)
    await state.set_state(Flow.free_plan)
    await m.answer('✅ Redeem code ၅ ခု batch စတင်ပါမယ်။ Plan ရွေးပါ။',reply_markup=kb([[('🇯🇵 JP','freeplan:jp'),('🇸🇬 SG','freeplan:sg')]]))

@dp.callback_query(F.data=='free')
async def free_start(q,state):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    await q.answer(); await q.message.answer('အသုံးပြုပုံ: /redeem GENERATED\nBot က customer redeem code ၅ ခု ထုတ်ပေးပါမယ်။ Customer က code တစ်ခုထည့်မှသာ Free key ရပါမယ်။')

@dp.callback_query(F.data.startswith('freeplan:'))
async def free_plan(q,state):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    plan=q.data.split(':',1)[1]
    if plan not in PLANS: return await q.answer('Plan မမှန်ပါ။',show_alert=True)
    await state.update_data(freeplan=plan,free_days_value=30); await state.set_state(Flow.free_days); await q.answer()
    await edit(q,'🎁 Free key သက်တမ်းကို ခလုပ်ဖြင့်ရွေးပါ။ Device ကန့်သတ်ချက်မှာ ၁ စက်ဖြစ်သည်။\nရွေးထားသောရက်: 30',free_days_keyboard(30))

def free_days_keyboard(days):
    days=max(1,min(3650,int(days)))
    return kb([
        [('−365 ရက်','freeday:-365'),('−30 ရက်','freeday:-30'),('−7 ရက်','freeday:-7'),('−1 ရက်','freeday:-1')],
        [('+1 ရက်','freeday:1'),('+7 ရက်','freeday:7'),('+30 ရက်','freeday:30'),('+365 ရက်','freeday:365')],
        [('7','freeday:set:7'),('14','freeday:set:14'),('30','freeday:set:30'),('60','freeday:set:60'),('90','freeday:set:90')],
        [('180','freeday:set:180'),('365','freeday:set:365'),('730','freeday:set:730'),('1825','freeday:set:1825'),('3650','freeday:set:3650')],
        [(f'✅ {days} ရက်ဖြင့် ဆက်သွားမည်','freeday:confirm')],
        [('❌ မလုပ်တော့ပါ','freeday:cancel')]
    ])

@dp.callback_query(F.data.startswith('freeday:'))
async def free_days_button(q,state):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    if await state.get_state()!=Flow.free_days.state: return await q.answer('ဒီရွေးချယ်မှု သက်တမ်းကုန်ပါပြီ။ /redeem ဖြင့် ပြန်စပါ။',show_alert=True)
    data=await state.get_data(); freeid=int(data.get('freeid',0)); creator=q.from_user.id
    action=q.data.split(':',1)[1]
    if action=='cancel':
        with db() as c: c.execute('UPDATE free_keys SET deleted_at=? WHERE id=? AND admin_id=? AND client_info IS NULL',(now(),freeid,creator))
        await state.clear(); await q.answer('Free key ထုတ်ခြင်းကို ပယ်ဖျက်ပြီးပါပြီ။'); await edit(q,'ပယ်ဖျက်ပြီးပါပြီ။',kb([[('⬅️ Admin','admin')]])); return
    if action=='confirm':
        days=max(1,min(3650,int(data.get('free_days_value',30)))); plan=data.get('freeplan')
        if plan not in PLANS: return await q.answer('Plan မတွေ့ပါ။ /redeem GENERATED ဖြင့် ပြန်စပါ။',show_alert=True)
        if not data.get('redeem_batch'): return await q.answer('Batch မတွေ့ပါ။ /redeem GENERATED ဖြင့် ပြန်စပါ။',show_alert=True)
        ps=panel_rows(True)
        if not ps:
            await state.clear(); await q.answer()
            return await edit(q,'Panel မထည့်ရသေးပါ။ Admin > Panel များမှ အရင်ထည့်ပါ။',kb([[('⬅️ Admin','admin')]]))
        batch_id=secrets.token_hex(8).upper()
        created=[]
        with db() as c:
            for _ in range(5):
                code='FREE-'+secrets.token_hex(5).upper()
                while c.execute('SELECT 1 FROM redeem_codes WHERE code=?',(code,)).fetchone(): code='FREE-'+secrets.token_hex(5).upper()
                cur=c.execute('INSERT INTO free_keys(admin_id,user_id,plan,months,devices,created,duration_days) VALUES(?,?,?,NULL,?,?,?)',(creator,0,plan,1,now(),days))
                freeid=cur.lastrowid
                c.execute('INSERT INTO redeem_codes(code,admin_id,free_key_id,batch_id,created) VALUES(?,?,?,?,?)',(code,creator,freeid,batch_id,now()))
                created.append(code)
        await state.clear()
        await q.answer()
        await edit(q,f'🎁 Redeem code batch • {PLANS[plan][0]} • {days} ရက် • ၅ ခု\nPanel ရွေးပါ။',kb([[(p['name'],f'pickpanel:batch:{batch_id}:{p["id"]}')] for p in ps]))
        return
    try:
        if action.startswith('set:'): days=int(action.split(':',1)[1])
        else: days=int(data.get('free_days_value',30))+int(action)
        if not 1<=days<=3650: raise ValueError()
    except ValueError: return await q.answer('သက်တမ်းကို ၁ မှ ၃,၆၅၀ ရက်အတွင်းထားပါ။',show_alert=True)
    await state.update_data(free_days_value=days); await q.answer(); await edit(q,f'🎁 Free key သက်တမ်းကို ခလုပ်ဖြင့်ရွေးပါ။ Device ကန့်သတ်ချက်မှာ ၁ စက်ဖြစ်သည်။\nရွေးထားသောရက်: {days}',free_days_keyboard(days))

@dp.callback_query(F.data.startswith('keytoggle:'))
async def key_toggle(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try:
        _,kind,key_id_s,enabled_s=q.data.split(':'); key_id=int(key_id_s); enabled=int(enabled_s)
        if kind not in ('o','f') or enabled not in (0,1): raise ValueError()
    except ValueError: return await q.answer('Key အချက်အလက်မမှန်ပါ။',show_alert=True)
    table='orders' if kind=='o' else 'free_keys'
    condition='status="completed" AND deleted_at IS NULL' if kind=='o' else 'client_info IS NOT NULL AND deleted_at IS NULL'
    with db() as c: r=c.execute(f'SELECT * FROM {table} WHERE id=? AND {condition}',(key_id,)).fetchone()
    if not r: return await q.answer('Key မှတ်တမ်းမတွေ့ပါ။',show_alert=True)
    try:
        info=json.loads(r['client_info'] or '{}'); email=info.get('email')
        if not email: raise XUIError('Key မှတ်တမ်းတွင် 3x-ui client email မရှိပါ။')
        p=panel_by_id(r['panel_id'])
        async with await client_panel(p) as api: await api.set_client_enabled(r['inbound_id'],email,bool(enabled))
        info['enabled']=bool(enabled)
        with db() as c: c.execute(f'UPDATE {table} SET key_enabled=?,client_info=? WHERE id=?',(enabled,json.dumps(info,ensure_ascii=False),key_id))
        status='ဖွင့်' if enabled else 'ပိတ်'
        await q.answer(f'Key {status}ပြီးပါပြီ။')
        try: await q.message.edit_reply_markup(reply_markup=key_status_markup(kind,key_id,enabled))
        except Exception: pass
        await q.message.answer(f'✅ {"အော်ဒါ" if kind=="o" else "Free key"} #{key_id} ကို {status}ပြီးပါပြီ။')
        if kind=='o':
            try: await bot.send_message(r['user_id'],f'{"✅" if enabled else "⏸️"} သင့်အော်ဒါ #{key_id} key ကို Admin မှ {status}ထားပါသည်။')
            except Exception as e: log.warning('Could not notify key owner %s: %s',r['user_id'],e)
    except Exception as e:
        await q.answer('3x-ui သို့ ပြောင်းလဲမှုမအောင်မြင်ပါ။',show_alert=True)
        await q.message.answer(f'❌ Key ကို {"ဖွင့်" if enabled else "ပိတ်"} မရပါ: {str(e)[:400]}')

@dp.callback_query(F.data.startswith('keydel:'))
async def key_delete_prompt(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try:
        _,kind,key_id_s=q.data.split(':'); key_id=int(key_id_s)
        if kind not in ('o','f'): raise ValueError()
    except ValueError: return await q.answer('Key အချက်အလက်မမှန်ပါ။',show_alert=True)
    table='orders' if kind=='o' else 'free_keys'
    clause='status="completed" AND deleted_at IS NULL' if kind=='o' else 'deleted_at IS NULL'
    with db() as c: r=c.execute(f'SELECT * FROM {table} WHERE id=? AND {clause}',(key_id,)).fetchone()
    if not r: return await q.answer('ဖျက်နိုင်သော key မတွေ့ပါ။',show_alert=True)
    info=json.loads(r['client_info'] or '{}')
    title='ဝယ်ယူထားသော key' if kind=='o' else 'Free key'
    details='3x-ui client ကိုပါ ဖျက်ပြီး subscription link ကို မှတ်တမ်းထဲမှဖယ်ရှားပါမည်။'
    if not info.get('email'): details='မပြီးသေးသော key request/မှတ်တမ်းကို ဖယ်ရှားပါမည်။ 3x-ui client မရှိပါ။'
    if kind=='o': details+='\nKey ပိတ်ခြင်း သို့မဟုတ် ဖျက်ခြင်းကြောင့် wallet ငွေပြန်အမ်းမည်မဟုတ်ပါ။'
    await q.answer()
    await edit(q,f'⚠️ {title} #{key_id} ကို ဖျက်ရန် သေချာပါသလား?\n{details}',kb([[('🗑️ ဖျက်ရန်အတည်ပြု',f'keydelconfirm:{kind}:{key_id}')],[('မဖျက်တော့ပါ',f'keydelcancel:{kind}')]]))

@dp.callback_query(F.data.startswith('keydelcancel:'))
async def key_delete_cancel(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try: kind=q.data.split(':',1)[1]
    except IndexError: kind=''
    await q.answer('မဖျက်တော့ပါ။')
    if kind=='o': return await edit(q,'Key ဖျက်ခြင်းကို ပယ်ဖျက်လိုက်ပါပြီ။',kb([[('🔑 ရောင်းပြီး key','soldkeys')],[('⬅️ Admin','admin')]]))
    await edit(q,'Key ဖျက်ခြင်းကို ပယ်ဖျက်လိုက်ပါပြီ။',kb([[('🎁 Free key မှတ်တမ်း','freekeys')],[('⬅️ Admin','admin')]]))

@dp.callback_query(F.data.startswith('keydelconfirm:'))
async def key_delete_confirm(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    try:
        _,kind,key_id_s=q.data.split(':'); key_id=int(key_id_s)
        if kind not in ('o','f'): raise ValueError()
    except ValueError: return await q.answer('Key အချက်အလက်မမှန်ပါ။',show_alert=True)
    table='orders' if kind=='o' else 'free_keys'
    clause='status="completed" AND deleted_at IS NULL' if kind=='o' else 'deleted_at IS NULL'
    with db() as c: r=c.execute(f'SELECT * FROM {table} WHERE id=? AND {clause}',(key_id,)).fetchone()
    if not r: return await q.answer('Key မတွေ့ပါ သို့မဟုတ် ဖျက်ပြီးပါပြီ။',show_alert=True)
    await q.answer('Key ကို 3x-ui panel မှ ဖျက်နေသည်…')
    try:
        info=json.loads(r['client_info'] or '{}')
        if info.get('email'):
            if not r['panel_id'] or not r['inbound_id']: raise XUIError('Key ၏ panel/inbound မှတ်တမ်းမပြည့်စုံပါ။')
            p=panel_by_id(r['panel_id'])
            async with await client_panel(p) as api:
                await api.delete_client(r['inbound_id'],info['email'],info.get('uuid') or info.get('id'))
        stamp=now()
        with db() as c:
            changed=c.execute(f'UPDATE {table} SET deleted_at=?,client_info=NULL,key_enabled=0 WHERE id=? AND {clause}',(stamp,key_id)).rowcount
        if not changed: return await q.message.answer('⚠️ ဖျက်နေစဉ် အခြားလုပ်ဆောင်မှုတစ်ခု ပြီးသွားပါသည်။ မှတ်တမ်းကို ပြန်စစ်ပါ။')
        if kind=='o':
            try: await bot.send_message(r['user_id'],f'🗑️ သင့်အော်ဒါ #{key_id} key ကို Admin မှ ဖျက်လိုက်ပါပြီ။ ငွေပြန်အမ်းမှု မပါဝင်ပါ။')
            except Exception as e: log.warning('Could not notify deleted key owner %s: %s',r['user_id'],e)
        title='ဝယ်ယူထားသော key' if kind=='o' else 'Free key'
        menu='soldkeys' if kind=='o' else 'freekeys'
        await edit(q,f'✅ {title} #{key_id} ကို 3x-ui မှဖျက်ပြီး Admin မှတ်တမ်းမှဖယ်ရှားလိုက်ပါပြီ။',kb([[('မှတ်တမ်းသို့ပြန်',''+menu)],[('⬅️ Admin','admin')]]))
    except Exception as e:
        await q.message.answer(f'❌ Key ကိုဖျက်မရပါ: {str(e)[:400]}\nPanel ကိုပြန်ထည့်/စစ်ဆေးပြီး ထပ်ကြိုးစားပါ။ မှတ်တမ်းကို မဖျက်ထားပါ။')

@dp.callback_query(F.data=='freekeys')
async def free_history(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    with db() as c: rs=c.execute('SELECT * FROM free_keys WHERE deleted_at IS NULL ORDER BY id DESC LIMIT 20').fetchall()
    await q.answer()
    if not rs: return await edit(q,'Free key မှတ်တမ်းမရှိပါ။',kb([[('⬅️ Admin','admin')]]))
    await edit(q,'🎁 Free key မှတ်တမ်း (နောက်ဆုံး ၂၀ ခု)')
    for r in rs:
        info=json.loads(r['client_info'] or '{}')
        term=f'{r["duration_days"]} ရက်' if r['duration_days'] else f'{r["months"] or "-"} လ'
        target='မည်သူမဆို အသုံးပြုနိုင်သည်' if not r['user_id'] else f'Customer {r["user_id"]}'
        key_state=('ဖွင့်ထား' if r['key_enabled'] else 'ပိတ်ထား') if info.get('email') else 'မထုတ်ရသေး'
        text=f'🎁 Free key #{r["id"]} • {target}\n{r["plan"] or "pending"} • {term} • {r["devices"] or "-"} စက်\nအခြေအနေ: {key_state}\n{info.get("inbound","")} • {info.get("email","")}\nကုန်မည့်ရက်: {info.get("expiry_text","")}\n'
        if info.get('subscription_url'): text += f'Subscription link: <code>{html.escape(info["subscription_url"])}</code>'
        enabled_state=bool(r['key_enabled']) if info.get('email') else None
        await q.message.answer(text,parse_mode='HTML',reply_markup=key_status_markup('f',r['id'],enabled_state))
    await q.message.answer('Admin မီနူး',reply_markup=kb([[('⬅️ Admin','admin')]]))
@dp.callback_query(F.data=='soldkeys')
async def sold_history(q):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    with db() as c: rs=c.execute('''SELECT o.*,u.name AS buyer_name,u.username AS buyer_username
        FROM orders o LEFT JOIN users u ON u.id=o.user_id
        WHERE o.status="completed" AND o.deleted_at IS NULL ORDER BY o.id DESC LIMIT 20''').fetchall()
    await q.answer()
    if not rs: return await edit(q,'ရောင်းပြီး key မှတ်တမ်းမရှိပါ။',kb([[('⬅️ Admin','admin')]]))
    for r in rs:
        info=json.loads(r['client_info'] or '{}')
        username='@'+r['buyer_username'] if r['buyer_username'] else 'username မရှိပါ'
        buyer=f'{r["buyer_name"] or "အမည်မရှိ"} ({username}) • ID {r["user_id"]}'
        text=f'🔑 ဝယ်ယူသူ: {buyer}\nOrder #{r["id"]}\n{PLANS[r["plan"]][0]} • {r["months"]}လ/{r["devices"]}စက် • {money(r["amount"])}\nအခြေအနေ: {"ဖွင့်ထား" if r["key_enabled"] else "ပိတ်ထား"}\n{info.get("inbound","")} • {info.get("email","")}\nသက်တမ်းကုန်: {info.get("expiry_text","")}\n'
        if info.get('subscription_url'): text+=f'Subscription link: <code>{html.escape(info["subscription_url"])}</code>'
        controls=[]
        if info.get('email'): controls.append([( '⏸️ Key ပိတ်ရန်' if r['key_enabled'] else '▶️ Key ပြန်ဖွင့်ရန်',f'keytoggle:o:{r["id"]}:{0 if r["key_enabled"] else 1}')])
        controls.append([('🗑️ Key ဖျက်ရန်',f'keydel:o:{r["id"]}')])
        controls.append([(f'👤 Customer အကောင့် ({r["user_id"]})',f'cust:{r["user_id"]}')])
        await q.message.answer(text,parse_mode='HTML',reply_markup=kb(controls))

@dp.callback_query(F.data=='adjust')
async def adjust_start(q,state):
    if not callback_admin(q): return await q.answer('ခွင့်မရှိပါ။',show_alert=True)
    await q.answer(); await state.update_data(target_uid=None); await state.set_state(Flow.admin_amount); await q.message.answer('Customer ID နှင့် ပမာဏကို space ခြား၍ပို့ပါ။\nဥပမာ `2146167427 5000` = ၅,၀၀၀ ထည့်\n`2146167427 -5000` = ၅,၀၀၀ နှုတ်',parse_mode='Markdown')
@dp.message(Flow.admin_amount)
async def adjust_apply(m,state):
    if not admin(m.from_user.id): return
    data=await state.get_data()
    try:
        if data.get('target_uid') is not None: uid=int(data['target_uid']); delta=int(m.text)
        else: uid,delta=map(int,m.text.split())
        assert delta!=0
    except: return await m.answer('ပမာဏကို 5000 သို့မဟုတ် -5000 ပုံစံဖြင့်ပို့ပါ။ Customer စာရင်းမှမဝင်ထားလျှင် Customer ID နှင့် ပမာဏကို space ခြားပို့ပါ။')
    with db() as c:
        c.execute('INSERT INTO users(id,name,created) VALUES(?,?,?) ON CONFLICT(id) DO NOTHING',(uid,'Customer',now())); b=c.execute('SELECT balance FROM users WHERE id=?',(uid,)).fetchone()['balance']
        if b+delta<0: return await m.answer('လက်ကျန်ထက်ပိုနှုတ်လို့မရပါ။')
        c.execute('UPDATE users SET balance=balance+? WHERE id=?',(delta,uid)); c.execute('INSERT INTO ledger(user_id,delta,note,admin_id,created) VALUES(?,?,?,?,?)',(uid,delta,'Admin adjustment',m.from_user.id,now()))
    await state.clear(); await m.answer(f'✅ ပြီးပါပြီ။ လက်ကျန် {money(balance(uid))}')
    try: await bot.send_message(uid,f'💰 Admin မှ {money(abs(delta))} {"ထည့်" if delta>0 else "နှုတ်"} ပေးထားပါတယ်။\nအကြောင်းရင်း: Admin မှ လက်ကျန်ငွေပြင်ဆင်မှု။\nလက်ကျန်: {money(balance(uid))}')
    except: pass

@dp.callback_query(F.data=='myorders')
async def my_orders(q):
    with db() as c: rs=c.execute('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 10',(q.from_user.id,)).fetchall()
    await q.answer()
    if not rs: return await edit(q,'အော်ဒါမရှိသေးပါ။',kb([[('🛍️ ဝယ်မည်','buy')],[('🏠 ပင်မမီနူး','home')]]))
    await edit(q,'📜 သင့်အော်ဒါ\n'+'\n'.join(f'#{r["id"]} • {r["plan"].upper()} • {r["months"]}လ/{r["devices"]}စက် • {money(r["amount"])} • {"Key ဖျက်ပြီး" if r["deleted_at"] else r["status"]}' for r in rs),kb([[('🏠 ပင်မမီနူး','home')]]))
@dp.callback_query(F.data=='help')
async def help_user(q): await q.answer(); await edit(q,'💬 မေးမြန်းလိုသည်များကို ဒီ bot ထဲရေးပို့ပါ။ Admin ဆီ တိုက်ရိုက်ရောက်ပါမယ်။',kb([[('🏠 ပင်မမီနူး','home')]]))
@dp.message(Command('reply'))
async def reply(m):
    if not admin(m.from_user.id): return
    p=m.text.split(maxsplit=2)
    if len(p)<3: return await m.answer('အသုံးပြုပုံ: /reply CUSTOMER_ID စာသား')
    try: await bot.send_message(int(p[1]),p[2]+'\n\n😊 ဝယ်ယူအားပေးမှုအတွက် ကျေးဇူးတင်ပါတယ်ဗျ။ အသိမိတ်ဆွေတွေကိုလည်း ညွှန်းပေးပါဦးနော်!'); await m.answer('✅ ပို့ပြီးပါပြီ။')
    except Exception as e: await m.answer('ပို့မရပါ: '+str(e)[:200])
async def redeem_customer_code(m,raw_code):
    code=str(raw_code or '').strip().upper()
    with db() as c:
        row=c.execute('''SELECT r.code,r.admin_id,r.free_key_id,r.used_by,f.* FROM redeem_codes r
            JOIN free_keys f ON f.id=r.free_key_id
            WHERE r.code=? AND r.used_by IS NULL AND f.deleted_at IS NULL AND f.client_info IS NULL''',(code,)).fetchone()
    if not row: await m.answer('❌ Redeem code မမှန်ပါ၊ အသုံးပြုပြီးပါပြီ သို့မဟုတ် သက်တမ်းမရှိတော့ပါ။'); return True
    if not row['panel_id'] or not row['inbound_id']:
        await m.answer('⏳ ဒီ code ကို Admin က ပြင်ဆင်နေဆဲပါ။ ခဏအကြာတွင် ပြန်ထည့်ပါ။'); return True
    with db() as c:
        claimed=c.execute('UPDATE redeem_codes SET used_by=?,used_at=? WHERE code=? AND used_by IS NULL',(m.from_user.id,now(),code)).rowcount
    if claimed!=1:
        await m.answer('❌ ဒီ code ကို အခြားသူက အသုံးပြုသွားပါပြီ။'); return True
    try:
        touch(m.from_user.id,m.from_user.full_name,m.from_user.username,m.from_user.first_name,m.from_user.last_name)
        panel=panel_by_id(row['panel_id'])
        info=await provision(panel,row['inbound_id'],m.from_user.id,row['plan'],row['months'] or 0,row['devices'] or 1,f'free{row["free_key_id"]}',True,duration_days=row['duration_days'])
        with db() as c:
            c.execute('''UPDATE free_keys SET user_id=?,client_info=?,connection_notified=0,first_connected_at=NULL,expiry_reminder_sent=0,expiry_reminder_at=?
                WHERE id=? AND client_info IS NULL AND deleted_at IS NULL''',(m.from_user.id,json.dumps(info,ensure_ascii=False),None,row['free_key_id']))
        await send_client(m.from_user.id,info,row['free_key_id'])
        for aid in set(ADMIN_IDS)|({int(row['admin_id'])} if row['admin_id'] else set()):
            try: await bot.send_message(aid,f'✅ Redeem code {code} ကို Customer က အသုံးပြုပြီး Free key ပို့ပြီးပါပြီ။\nCustomer: {m.from_user.full_name}\nTelegram ID: {m.from_user.id}\nFree key #{row["free_key_id"]}')
            except Exception as e: log.warning('Could not notify Admin about redeemed code %s: %s',code,e)
    except Exception as e:
        with db() as c: c.execute('UPDATE redeem_codes SET used_by=NULL,used_at=NULL WHERE code=? AND used_by=?',(code,m.from_user.id))
        await m.answer(f'❌ Free key ထုတ်မရပါ: {str(e)[:400]}')
    return True

@dp.message(F.text)
async def customer_text(m):
    if not admin(m.from_user.id):
        with db() as c: is_code=c.execute('SELECT 1 FROM redeem_codes WHERE code=? AND used_by IS NULL',(m.text.strip().upper(),)).fetchone()
        if is_code: return await redeem_customer_code(m,m.text)
    if admin(m.from_user.id): return
    touch(m.from_user.id,m.from_user.full_name,m.from_user.username,m.from_user.first_name,m.from_user.last_name)
    for aid in ADMIN_IDS: await bot.send_message(aid,f'📩 Customer စာ\n{m.from_user.full_name} (@{m.from_user.username or "-"})\nID {m.from_user.id}\n\n{m.text}\n\nပြန်ရန်: /reply {m.from_user.id} စာသား')
    await m.answer('📨 သင့်စာကို Admin ဆီပို့ပြီးပါပြီ။')
@dp.message(F.photo|F.document|F.video|F.voice)
async def customer_media(m):
    if admin(m.from_user.id): return
    touch(m.from_user.id,m.from_user.full_name,m.from_user.username,m.from_user.first_name,m.from_user.last_name)
    for aid in ADMIN_IDS:
        await bot.send_message(aid,f'📩 Customer media • {m.from_user.full_name} ID {m.from_user.id}\n{m.caption or ""}\nပြန်ရန်: /reply {m.from_user.id} စာသား')
        await bot.copy_message(aid,m.chat.id,m.message_id)
    await m.answer('📨 Admin ဆီပို့ပြီးပါပြီ။')

@dp.message()
async def customer_other_message(m):
    if admin(m.from_user.id): return
    touch(m.from_user.id,m.from_user.full_name,m.from_user.username,m.from_user.first_name,m.from_user.last_name)
    for aid in ADMIN_IDS:
        await bot.send_message(aid,f'📩 Customer မှ အခြား message ပို့ထားသည် • {m.from_user.full_name} • ID {m.from_user.id}\nပြန်ရန်: /reply {m.from_user.id} စာသား')
        await bot.copy_message(aid,m.chat.id,m.message_id)
    await m.answer('📨 Admin ဆီပို့ပြီးပါပြီ။')

async def check_first_connections():
    pending_by_panel={}
    with db() as c:
        orders=c.execute('''SELECT id,user_id,plan,months,devices,panel_id,inbound_id,client_info,connection_notified
            FROM orders WHERE status="completed" AND deleted_at IS NULL AND key_enabled=1
            AND client_info IS NOT NULL AND connection_notified=0''').fetchall()
        free_keys=c.execute('''SELECT id,admin_id,user_id,plan,months,devices,panel_id,inbound_id,client_info,connection_notified
            FROM free_keys WHERE deleted_at IS NULL AND key_enabled=1
            AND client_info IS NOT NULL AND connection_notified=0''').fetchall()
    for kind,rows in (('o',orders),('f',free_keys)):
        for row in rows:
            try:
                info=json.loads(row['client_info'] or '{}'); email=str(info.get('email') or '')
                pid=int(row['panel_id'])
            except (TypeError,ValueError,json.JSONDecodeError):
                log.warning('Skipping malformed key record kind=%s id=%s',kind,row['id']); continue
            if not email: continue
            pending_by_panel.setdefault(pid,[]).append({'kind':kind,'row':row,'info':info,'email':email})
    for pid,items in pending_by_panel.items():
        try:
            panel=panel_by_id(pid)
            async with await client_panel(panel) as api:
                online=await api.online_clients()
                # HWID is read as evidence/metadata for the same client. The
                # online heartbeat remains the notification gate, so importing
                # a subscription alone cannot create a false connection event.
                for item in items:
                    if item['email'] in online:
                        try: item['hwid']=await api.hwid_status(item['email'])
                        except Exception as e:
                            log.warning('HWID status unavailable for %s on panel %s: %s',item['email'],pid,e)
                            item['hwid']={'count':None,'limit':None,'available':False}
        except Exception as e:
            log.warning('First-connection check failed for panel %s: %s',pid,e); continue
        for item in items:
            if item['email'] not in online: continue
            row=item['row']; kind=item['kind']; table='orders' if kind=='o' else 'free_keys'; stamp=now()
            with db() as c:
                changed=c.execute(f'''UPDATE {table} SET connection_notified=1,first_connected_at=?
                    WHERE id=? AND connection_notified=0 AND deleted_at IS NULL''',(stamp,row['id'])).rowcount
                if changed==1:
                    if kind=='o':
                        customer_id=int(row['user_id']); creator=None
                        user=c.execute('SELECT name,username FROM users WHERE id=?',(customer_id,)).fetchone()
                        customer_name=user['name'] if user else None; username=user['username'] if user else None
                    else:
                        customer_id=None; customer_name=None; username=None; creator=int(row['admin_id'] or 0) or None
                    hwid=item.get('hwid') or {}
                    c.execute('''INSERT INTO connection_events(key_type,key_id,customer_id,customer_name,username,issuer_admin_id,plan,panel_name,inbound,client_email,client_app,hwid_count,hwid_limit,event_type,connected_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?,NULL,?,?, 'first_connection',?)''',(
                        'paid' if kind=='o' else 'free',int(row['id']),customer_id,customer_name,username,creator,
                        str(row['plan'] or ''),str(item['info'].get('panel_name') or ''),str(item['info'].get('inbound') or ''),item['email'],
                        hwid.get('count'),hwid.get('limit'),stamp))
            if changed!=1: continue
            info=item['info']; plan=PLANS.get(str(row['plan'] or '').lower(),(str(row['plan'] or 'VPN'),0))[0]
            hwid=item.get('hwid') or {}; hwid_count=hwid.get('count'); hwid_limit=hwid.get('limit')
            hwid_text=(f'{hwid_count}/{hwid_limit} registered' if hwid_count is not None and hwid_limit not in (None,0) else (f'{hwid_count} registered' if hwid_count is not None else 'မရရှိပါ'))
            when=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
            if kind=='o':
                uid=int(row['user_id']); order_id=int(row['id'])
                user_label=f'{customer_name or "အမည်မသိ"} (@{username})' if username else (customer_name or 'အမည်မသိ')
                customer_text=(f'🟢 သင့် VPN key ကို ပထမဆုံးအကြိမ် server သို့ ချိတ်ဆက်အသုံးပြုကြောင်း အတည်ပြုရရှိပါသည်။\n'
                    f'အော်ဒါ #{order_id} • {plan}\n📡 {info.get("inbound","-")}\n🕒 {when}\n'
                    f'🔐 HWID: {hwid_text}\n📱 App အမည်: မည်သည့် app ဖြစ်သည်ကို 3x-ui online API မှ မခွဲခြားနိုင်ပါ။')
                admin_text=(f'🔔 Customer VPN key ပထမဆုံးချိတ်ဆက်မှု\nအော်ဒါ #{order_id} • {plan}\n'
                    f'Customer: {user_label}\nTelegram ID: {uid}\nPanel: {info.get("panel_name","-")} • Inbound: {info.get("inbound","-")}\n'
                    f'🕒 {when}\n🔐 HWID: {hwid_text}\n📱 App အမည်: မည်သည့် app ဖြစ်သည်ကို 3x-ui online API မှ မခွဲခြားနိုင်ပါ။')
                try: await bot.send_message(uid,customer_text)
                except Exception as e: log.warning('Could not send first-connection message to customer %s: %s',uid,e)
                for aid in ADMIN_IDS:
                    if aid==uid: continue
                    try: await bot.send_message(aid,admin_text)
                    except Exception as e: log.warning('Could not notify Admin %s about order %s connection: %s',aid,order_id,e)
            else:
                free_id=int(row['id']); creator=int(row['admin_id'] or 0)
                admin_text=(f'🔔 Free key ပထမဆုံးချိတ်ဆက်မှု\nFree key #{free_id} • {plan}\n'
                    f'Panel: {info.get("panel_name","-")} • Inbound: {info.get("inbound","-")}\n🕒 {when}\n'
                    f'🔐 HWID: {hwid_text}\n📱 App အမည်: မည်သည့် app ဖြစ်သည်ကို 3x-ui online API မှ မခွဲခြားနိုင်ပါ။\n'
                    'ဤ key ကိုမျှဝေသုံးနိုင်သောကြောင့် အသုံးပြုသူ၏ Telegram ID ကို မသိနိုင်ပါ။')
                for aid in set(ADMIN_IDS)|({creator} if creator else set()):
                    try: await bot.send_message(aid,admin_text)
                    except Exception as e: log.warning('Could not notify Admin %s about Free key %s connection: %s',aid,free_id,e)

async def check_expiry_reminders(now_ms=None):
    current_ms=int(now_ms if now_ms is not None else datetime.now(timezone.utc).timestamp()*1000)
    cutoff_ms=current_ms+48*60*60*1000; candidates=[]
    with db() as c:
        orders=c.execute('''SELECT id,user_id,plan,client_info FROM orders WHERE status="completed"
            AND deleted_at IS NULL AND key_enabled=1 AND client_info IS NOT NULL AND expiry_reminder_sent=0''').fetchall()
        free_keys=c.execute('''SELECT id,admin_id,plan,client_info FROM free_keys WHERE deleted_at IS NULL
            AND key_enabled=1 AND client_info IS NOT NULL AND expiry_reminder_sent=0''').fetchall()
    for kind,rows in (('o',orders),('f',free_keys)):
        for row in rows:
            table='orders' if kind=='o' else 'free_keys'
            try:
                info=json.loads(row['client_info'] or '{}')
                if not isinstance(info,dict): raise ValueError('client_info is not an object')
                expires_ms=int(info.get('expiry_ms') or 0)
            except (TypeError,ValueError,json.JSONDecodeError):
                log.warning('Invalid expiry metadata for key kind=%s id=%s',kind,row['id']); expires_ms=0
            if not expires_ms or expires_ms<=current_ms:
                with db() as c: c.execute(f'UPDATE {table} SET expiry_reminder_sent=1 WHERE id=? AND expiry_reminder_sent=0',(row['id'],))
                continue
            if expires_ms<=cutoff_ms: candidates.append((kind,table,row,info,expires_ms))
    sent_count=0
    for kind,table,row,info,expires_ms in candidates:
        stamp=now()
        with db() as c:
            claimed=c.execute(f'''UPDATE {table} SET expiry_reminder_sent=1,expiry_reminder_at=?
                WHERE id=? AND expiry_reminder_sent=0 AND deleted_at IS NULL''',(stamp,row['id'])).rowcount
        if claimed!=1: continue
        remaining_hours=max(1,(expires_ms-current_ms+3_599_999)//3_600_000)
        expiry_text=datetime.fromtimestamp(expires_ms/1000,timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
        plan=PLANS.get(str(row['plan'] or '').lower(),(str(row['plan'] or 'VPN'),0))[0]
        if kind=='o':
            uid=int(row['user_id'])
            text=(f'⏰ သင့် {plan} VPN key သက်တမ်းကုန်ရန် ၂ ရက်အတွင်း ဖြစ်ပါသည်။\n'
                  f'⏳ ခန့်မှန်းကျန်သက်တမ်း: {remaining_hours} နာရီ\n📅 ကုန်ဆုံးချိန်: {expiry_text}\n'
                  'ဆက်လက်အသုံးပြုလိုပါက သက်တမ်းမကုန်မီ Admin ကို ဆက်သွယ်ပါ။')
            try: await bot.send_message(uid,text)
            except Exception as e: log.warning('Could not send expiry reminder to customer %s for order %s: %s',uid,row['id'],e)
        else:
            creator=int(row['admin_id'] or 0)
            if creator:
                text=(f'⏰ Free key #{row["id"]} • {plan} သက်တမ်းကုန်ရန် ၂ ရက်အတွင်း ဖြစ်ပါသည်။\n'
                      f'⏳ ခန့်မှန်းကျန်သက်တမ်း: {remaining_hours} နာရီ\n📅 ကုန်ဆုံးချိန်: {expiry_text}\n'
                      'Free key သည် မျှဝေသုံးစွဲရန် ဖြစ်သောကြောင့် သက်ဆိုင်သူကို Admin မှ အသိပေးပါ။')
                try: await bot.send_message(creator,text)
                except Exception as e: log.warning('Could not send Free-key expiry reminder to Admin %s for key %s: %s',creator,row['id'],e)
        sent_count+=1
    return sent_count

async def connection_monitor():
    while True:
        try: await check_first_connections()
        except Exception: log.exception('First-connection monitor cycle failed')
        await asyncio.sleep(20)

async def expiry_reminder_monitor():
    while True:
        try: await check_expiry_reminders()
        except Exception: log.exception('Expiry reminder monitor cycle failed')
        await asyncio.sleep(15*60)

async def main():
    init_db(); monitors=[asyncio.create_task(connection_monitor(),name='vpn-first-connection-monitor'),asyncio.create_task(expiry_reminder_monitor(),name='vpn-expiry-reminder-monitor')]
    log.info('Bot polling started, admin ids=%s',sorted(ADMIN_IDS))
    try: await dp.start_polling(bot)
    finally:
        for monitor in monitors: monitor.cancel()
        for monitor in monitors:
            try: await monitor
            except asyncio.CancelledError: pass
if __name__=='__main__': asyncio.run(main())
