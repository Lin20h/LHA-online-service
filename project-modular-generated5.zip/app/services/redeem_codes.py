"""Pure redeem-code utilities shared by the batch redeem workflow."""
import secrets

def generate_code(existing):
    """Return a unique customer-facing one-time code."""
    while True:
        code = 'FREE-' + secrets.token_hex(5).upper()
        if code not in existing:
            return code

def generate_batch_codes(count=5, existing=()):
    """Generate exactly count unique codes for one admin batch."""
    used = set(existing)
    result = []
    while len(result) < count:
        code = generate_code(used)
        used.add(code)
        result.append(code)
    return result
