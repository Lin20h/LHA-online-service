"""Production entrypoint for the Telegram VPN shop bot."""
import asyncio
from app.legacy_bot import main

if __name__ == '__main__':
    asyncio.run(main())
